# CP69-N: exact symplectic and section-area lemmas, proof obligations and trust boundary

## Definitions inherited unchanged
Physical coordinates `x=(q1,q2,p1,p2)`; canonical form `omega=dq1∧dp1+dq2∧dp2`; `J=[[0,I],[-I,0]]`. Hamiltonian

H=(p1²−2cos(q1−q2)p1p2+2p2²)/(2(2−cos²(q1−q2)))−2cos q1−cos q2.

CP69-L/M rational lift `y=(q1,q2,p1,p2,s1,c1,s2,c2)` has C=c1c2+s1s2, D=s1c2−c1s2, Delta=2−C², `u=(p1−C p2)/Delta`, `v=(2p2−C p1)/Delta`, and field `f8=(u,v,−Duv−2s1,Duv−s2,c1u,−s1u,c2v,−s2v)`. Reduced CP69-M 24D variational equation `V'=A4(y)V`, `V(0)=I4`, uses the CP69-M rational `A4`, not the former 20D C1 integrator.

## Theorem N1 (off-phase infinitesimal symplecticity) — analytic PASS

For every y∈R8 with Delta≠0, `A4(y)^T J + J A4(y)=0`. This identity does NOT require `s_i²+c_i²=1` or `s_i=sin(q_i)`.

**Conceptual proof independently of the original Jacobian implementation.** Freeze `(s1,c1,s2,c2)` at the given y and introduce local coordinates `a1,a2`. Put

`S_i(a_i)=s_i cos(a_i)+c_i sin(a_i)` and `C_i(a_i)=c_i cos(a_i)−s_i sin(a_i)`.

Let `C(a)=C_1(a1)C_2(a2)+S_1(a1)S_2(a2)`. Define the *local frozen-phase Hamiltonian*

`H_y(a,p)= (p1²−2C(a)p1p2+2p2²)/(2(2−C(a)²)) − 2 C_1(a1) − C_2(a2)`.

At `a=0`, `∂a1 C=−D`, `∂a2 C=D`, `∂a1 D=C`, `∂a2 D=−C`; also `∂C H_kin=−u v` and `∂p H_kin=(u,v)`. Therefore `J∇_{a,p}H_y(0,p)=f4(y)` and `J Hess_{a,p}H_y(0,p)=A4(y)`. Hessian is symmetric, so `A4^T J + J A4=0`.

For the exact 24D ODE, `(V^T J V)'=0`. With `V(0)=I`, `V(t)^T J V(t)=J`, `det V=1` (det+ follows continuity at t=0), `V^{-1}=−J V^T J`. These statements hold for arbitrary off-phase lifted trajectories where the rational denominator stays nonzero. **Off-phase symplecticity is NOT a proof of physical phase consistency.**

`cp69n_symbolic_hamiltonian.py` independently evaluates all four Hamiltonian vector-field and all sixteen Hessian entries with SymPy and checks the 16 infinitesimal-symplectic entries, all PASS. No Lean build performed.

## Theorem N2 (constant symplectic area of CP69-G local C2 surface) — analytic PASS

The *source* (u,v)-surface lies in `H=−9/10, p1=0`, and has explicitly `q2=b0+p(u+v+h2 u²)`, `p2=q(u−v−h2 u²)`, `p1=0`, with `q1` uniquely determined by H. Here **p and q are exact supplied decimal rational constants** p=0.8242999233, q=0.5661533683.

Its pullback form is `dq2∧dp2`, because `dp1=0`, so

```
  omega(x_u,x_v)=q2_u p2_v−p2_u q2_v
    = p(1+2h2u)(−q) − q(1−2h2u)p
    = −2pq = −46668017806572665139/50000000000000000000.
```

A Hamiltonian flow preserves omega: `omega(z_u(t),z_v(t))=−2pq`. Since this is CONSTANT in u,v, the second-order identities are

`omega(z_uu,z_v)+omega(z_u,z_uv)=0`,
`omega(z_uv,z_v)+omega(z_u,z_vv)=0`.

The full C2 24-jet trace contains exactly these five derivative vectors (two first and three second). An independent `Fraction`/dyadic audit of 268 local time states (initial + 267 endpoints), both full strip and center, checked **536 × 3=1608 invariant enclosures**, with no imports of the previous C2 ODE checker. ALL PASS. This checks internal consistency of the stored trace, **not its ODE real-soundness**. In particular positive enclosure margins on endpoints do not turn this into a Lean-certified C2 proof.

## Corollary N3 (Poincaré nondegeneracy without a numerical 2×2 determinant) — CONDITIONAL geometric PASS

Assume the CP69-K transverse event exists and is the same uniquely selected section crossing `p1=0` for all (u,v) in the source strip, and the Hamiltonian energy is exactly −9/10. Write `Y(u,v)=Phi_{tau(u,v)}(x(u,v))`. The event speed `dot p1≠0` gives a C1 event time via the implicit-function theorem; also `∂H/∂q1=−dot p1≠0` means `(q2,p2)` are valid local coordinates on the section `{H=−9/10,p1=0}`.

Differentiating `Y` in u,v produces terms in the flow direction `f(Y)` times `tau_u,tau_v`. But `omega(f(Y),D Phi x_j)=dH(D Phi x_j)=0` because `x_j` is tangent to the energy level. Hence `omega(Y_u,Y_v)=omega(x_u,x_v)`. Since `dp1=0` on the return section,

`det d(q2,p2)(Y)/d(u,v) = -2pq != 0`.

Thus the local section-to-section map is a C1 local diffeomorphism; no separate interval estimate of this *2x2 determinant* is needed once the upstream existence and event transversality conditions are established. This does NOT establish the original global horseshoe theorem without its other bridge lemmas.

## Exact bounds from the saved 24D certificate — internal exact-arithmetic PASS with upstream meaning conditional

Audit of all 1488 24D endpoint boxes (integer grid 10^45 interpreted as exact Fraction intervals):

- All `V^T J V = J` sixteen scalar quadratic equations contain their expected constant: **23,808 conditions PASS**.
- All `det(V)=1` Leibniz interval expressions contain 1: **1,488 conditions PASS**.
- **Every arbitrary real matrix in each ENDPOINT interval box** satisfies `0.84 < det V < 7/6` via independent full 24-permutation Leibniz interval arithmetic. Strict bound stored with exact Fraction endpoints; hence all such endpoint matrices are nonsingular, not merely the true symplectic matrix.
- Total certificate forward endpoint `||V||_1 < 2201/250 = 8.804`; all endpoint `||V||_infty<9`. Along all Picard variation TUBES, max `||V||_1, ||V||_infty < 13`. If 24D ODE real soundness holds, the **true flow** satisfies `||V(t)^-1||_infty = ||V(t)||_1 < 13` for all covered times, and <8.804 at step endpoints. No backward ODE integration required.
- For 1488 Picard 8D state boxes and 1488 physical endpoints, natural exact Fraction interval computation establishes uniformly `Delta=2−C² > 33/50`, with minimum lower endpoint approx 0.66229990705. All 2976 boxes also have intervals for s1²+c1², s2²+c2², C²+D² that CONTAIN 1; containment alone does not assert the entire box satisfies those invariants.

Internal certificate checks depend on the mathematical assumption that stored intervals mean exact closed real intervals and that source files were not modified, plus the Python checker being implemented correctly. Machine-checked Lean real-soundness is not established.

## Adversarial outcomes — PASS

1. A diagonal matrix diag(2,1,1,1) fails the symplectic pairing test.
2. Tampering the final center C2-jet `q2_u` with exactly 0 excludes the conserved area −2pq.
3. A lifted state with q1=q2=0, s1=1,c1=0,s2=0,c2=1, p1=p2=0 has nonphysical p1'=−2 despite the reduced variational Hamiltonian structure: **symplecticity alone cannot replace initial phase certification**.
4. A lifted box with C∈[1,2] can contain a pole Delta=0; the observed >33/50 positivity is a real nontrivial required check.
5. `V=I` is symplectic even when falsely used as an ODE endpoint; invariance does not replace Picard/Taylor enclosure.
6. A direct bilinear symplectic interval contractor on all twelve final 4×4 Jacobian boxes did **not** narrow any of the 192 entries. This is a negative experimental finding, not a theorem that nonlinear invariant contractors cannot help; do not overstate its power.

## Remaining OPEN and checkpoint

The critical external proof obligation remains **formal real-soundness for actual integer interval arithmetic, Taylor series, and Picard checker + complete geometric connection to true local Wu and multishooting**. Source CP69-M remains in force. This new branch CP69-N proves/validates an additional Hamiltonian invariant, area-based Poincaré invertibility, and strict independent consistency tests. The final nontrivial transverse homoclinic orbit and Smale–Birkhoff horseshoe remain **CHECK**.
