# CP69-M: 24D rational lift, exact integral interval certificate, and 35D geometry — soundness contract

## Formal theorem to be proved in Lean or another trusted foundation

Let x∈R⁴ be an initial phase point in one of 12 accepted source boxes and H(x)=−9/10. Let ι(x)=(x,sin q1,cos q1,sin q2,cos q2). Let f8 and A4 be the rational maps in `HOMOCLINIC_CP69M_2026-11-19_研究報告.md`. Let (y,V) solve the *24D* ordinary differential equation

\[y'=f_8(y),\quad V'=A_4(y)V,\quad y(0)=\iota(x),\ V(0)=I_4.\]

**The goal of the real-soundness port** is to prove, with no unproved numerical or software axioms, that for all 12 source boxes, all 124 time steps, and every exact initial phase point in the initial box, the true physical flow \(\phi_{kh}(x)\) and its derivative \(D\phi_{kh}(x)\) are contained in the respective 4 state and 16 variational projections of the integer endpoint interval certificates. An analogous theorem is required for CP69-L 8D C0 and CP69-K 24D C2 local return.

### Algebraic phase-lift lemma — mathematical PASS

Define C=c1c2+s1s2 and D=s1c2−c1s2 and d=2−C². The vector field is

\[f_8=(u,v,-Duv-2s_1,Duv-s_2,c_1u,-s_1u,c_2v,-s_2v)\]

with u=(p1−Cp2)/d, v=(2p2−Cp1)/d. At initial conditions y=ι(x) the s/c variables solve the same 2D rotation ODE as (sin q_i,cos q_i). Uniqueness implies y(t)=ι(φ_t(x)); along the true graph C²+D²=1 and d≥1. Derivatives of the initial lift are fixed by ds_i=c_i dq_i, dc_i=−s_i dq_i. The map A4 is obtained by the chain rule on this manifold; it equals Df4 after composition with ι. Therefore V(t)=Dφ_t(x) by uniqueness of the 4×4 variational ODE. The analytic quotient rule and 16 SymPy identities support this; the proof is elementary calculus, not a Lean theorem.

### Grid interval arithmetic lemma — mathematical PASS, implementation trust CHECK

M=10^45, interval `[a,b]` means the exact real interval [a/M,b/M]. For addition, negation and subtraction the endpoints are exact. For multiplication use min/max of four endpoint integer products, floor the minimum/M and ceil the maximum/M. For reciprocal of a denominator interval not containing 0, floor M²/b and ceil M²/a. These operations contain the true real arithmetic results, including sign-reversed intervals. Fixed-point conversions Q→grid round outward by integer floor/ceil. All denominators containing 0 must be rejected.

The independent source checker `cp69m_dual_arithmetic_checker.py` and the distinct reduced checker `cp69m_independent_24d_checker.py` implement these rules. They are not themselves machine-proved correct. A Lean port must define their semantics by an explicit `repr : Int × Int → Set ℝ`, prove the operation lemmas, and prove `eval_cert_success → real_enclosure`.

### Initial phase lemma — mathematical PASS, implementation trust CHECK

Given a source angle interval with midpoint m, radius w, |m|<9, use the 45-term Maclaurin sum for sin (degree 89) or cos (degree 88). Lagrange remainder is bounded by |m|^90/90! or |m|^89/89! respectively. The slope of sin/cos has absolute value at most 1, so include an additional ±w. Every bound is a finite Fraction expression rounded outward. This avoids π in the new 40D/24D time-integrators. `CP69M_INITIAL_ANCHORS.json` ties the exact physical first-step boxes to original CP69-L CP69F 20D C1 source records, each with a fresh SHA check against the parent ZIP. Note this proves only *source provenance*, not the existence of a true unstable-manifold point in the source box, which depends on the earlier Wu geometry proof.

### Picard–Taylor one-step soundness — mathematical PASS conditional on true interval implementation

For z'=G(z) with G C∞ on a neighborhood of a compact box B free of poles, suppose for initial box X and time h>0 the checker verifies

\[ X+[0,h]G(B)\subset\operatorname{int}B. \]

For each z0∈X, local existence and uniqueness hold by local Lipschitz continuity. An earliest exit from B before time h would satisfy z(t)=z0+∫₀ᵗG(z(s)) ds ∈ X+[0,h]G(B)⊂int B, contradiction; hence the true solution exists and remains inside B through h.

Define formal time series coefficients z_k recursively from z_0 (or any point of B), via z_{k+1}=[t^k]G(∑_{j≤k}z_j t^j)/(k+1). Algebraic coefficient arithmetic (sum, product, inverse with no zero in the constant term) makes z_k precisely z^{(k)}(0)/k!. Taylor’s theorem gives

\[z(h)\in\sum_{k=0}^{n}Z_k(X) h^k+Z_{n+1}(B) h^{n+1}.\]

The checker's `output.contains(expression)` checks this inclusion componentwise. Since every new input box equals the preceding validated output in *all 24 or 40 components* and the first input covers the exact phase lift and its variational initial conditions, mathematical induction establishes whole-chain enclosures. We do **not** assert Lean has checked the interval or polynomial implementation.

### 35D physical contraction — conditional PASS

Given the accepted 24D endpoint physical variation and CP69-L 8D C0 center output, 11 energy-coordinate charts χ_j with ∂_eH≠0, and a known true unstable source curve within E0,E1 of its proxy, the 35D residual F and Jacobian intervals are assembled via the multishooting chain rule. A true-vs-proxy source change affects only the first 3 rows of the 35D residual and u-column of its Jacobian. For C the fixed candidate inverse/preconditioner, these yield an entrywise nonnegative Jacobian defect majorant B and fixed-point center residual a. The new **independently certified** first-segment derivative bound is

\[\|D\phi\|_\infty<8.486,\]

not the narrower 8.485092 inherited from the old 20D computation. If B≥0, a≥0, \(\|B\|_\infty<1\), and strictly positive h satisfies \(a+Bh<h\) in every coordinate, the map T(x)=x−CF(x) maps the coordinate box x0+[-h,h] strictly into itself and is a contraction. Banach supplies a unique zero in that box; C must also be injective: this is now checked independently by an exact modular rank certificate. The fixed rational matrix has denominator 10^45 and integer numerator Cnum. Reducing Cnum mod the proven prime 1,000,000,007 and performing exact modular Gaussian elimination gives full rank 35 and nonzero determinant residue 459,535,175. If det(Cnum)=0 over integers its residue would be zero, contradiction. Thus C is rationally invertible and T(x)=x implies F(x)=0. This is a finite unconditional arithmetic PASS, not a Lean kernel certificate. In the present finite verification, \(\max h_i=1.492823\times10^{-10}\) with all 35 inequalities strict. The first-box and all-chart physical meanings, together with E0,E1, remain named geometric preconditions.

## Provable vs. not yet machine-proved

**PASS as mathematical lemmas**: phase lift, quotient-chain-rule 24D reduction, exact-grid arithmetic *rules*, Picard/Taylor exit-time and remainder theorem, componentwise Banach–Krawczyk criterion.

**Internally reproduced PASS conditional on checker soundness**: 1,488 steps×80 conditions in 40D; 1,488×48 conditions in 24D; original 12 physical anchors; full 35D regenerated from original parent ZIP + new 24D; 35 positive Krawczyk component inequalities using Fraction.

**OPEN**: Lean kernel proof that the *actual implementation and input parsing* respect the real-valued interval arithmetic/series semantics, including exact time remainders; a fully independent authenticated verification of the true local unstable graph, C2 event branch, energy lifts, and assembled homoclinic geometry. The Birkhoff–Smale conclusion stays conditional until these close.

## Adversarial safeguards

1. A 40D ODE certificate can be valid even when the 35D norm bound fails; the raw 40D derivative intervals yield θ≈1.972799>1. Thus `C1-ODE-PASS` must not be conflated with `35D-KRAWCZYK-PASS`.
2. Changing the algebraic representation of Df8 changes interval overestimation. An independently expanded Jacobian can overrun a narrow box even when analytically equal; only an actual inclusion check can accept a box.
3. Using an inherited Dφ<8.485092 bound with the new 24D witnesses is invalid: their certified bound is 8.485196596767889...<8.486. All 35D and componentwise calculations were recomputed with 8.486.
4. Successful checks of all algebraic steps do not imply phase initial consistency, genuine Wu source membership, or transversality without their own proofs.
5. `python -O` is rejected; SHA and source anchoring, four intentional certificate mutations, strict inequalities with `Fraction` instead of floats are used. None of these alone constitutes an externally formal verified kernel.
