// Exact independent integer verifier of the raw 35D interval matrix.
// Build: g++ -std=c++17 -O2 cp69r_finite.cpp -o finite
#include <boost/multiprecision/cpp_int.hpp>
#include <iostream>
#include <vector>
#include <stdexcept>
using Z=boost::multiprecision::number<boost::multiprecision::cpp_int_backend<>, boost::multiprecision::et_off>;
const int N=35;
struct I{Z lo,hi;};
void req(bool b,const char*s){if(!b)throw std::runtime_error(s);}
Z read(){Z x;req(bool(std::cin>>x),"read");return x;}
I ri(){I a{read(),read()};req(a.lo<=a.hi,"interval order");return a;}
I add(I a,I b){return {a.lo+b.lo,a.hi+b.hi};}
I neg(I a){return {-a.hi,-a.lo};}
I scale(I a,Z c){if(c<0)return {c*a.hi,c*a.lo};return {c*a.lo,c*a.hi};}
Z mag(I a){Z x=-a.lo;return x>a.hi?x:a.hi;}
int main(){try{
 Z M=read(),K=read(),e0=read(),e1=read();
 req(M==pow(Z(10),45)&&K==pow(Z(10),30),"scale");
 req(e0==Z(8486)*1725*pow(Z(10),26)&&e1==Z(8486)*1542*pow(Z(10),31),"correction"); // 8.486*1.725e-13, 8.486*1.542e-8 times M
 Z M2=M*M;std::vector<std::vector<Z>> C(N,std::vector<Z>(N));
 std::vector<std::vector<I>> J(N,std::vector<I>(N)),A=J;
 for(auto &r:C)for(auto &x:r)x=read();
 for(auto &r:J)for(auto &x:r)x=ri();
 std::vector<I> R(N);for(auto &x:R)x=ri();
 std::vector<Z> h(N),v(N),x(N);for(auto &z:h)z=read();for(auto &z:v)z=read();for(auto &z:x)z=read();
 for(int i=0;i<3;i++){J[i][0]=add(J[i][0],{-e1,e1});R[i]=add(R[i],{-e0,e0});}
 for(int i=0;i<N;i++)for(int j=0;j<N;j++){
  I t{0,0};for(int k=0;k<N;k++)t=add(t,scale(J[k][j],C[i][k]));
  A[i][j]=add({i==j?M2:Z(0),i==j?M2:Z(0)},neg(t));
 }
 Z mn=0,ml=0,mr=0,whn=0,whd=1,wvn=0,wvd=1;for(int i=0;i<N;i++){
  req(h[i]>0&&v[i]>0&&h[i]*pow(Z(10),7)<K,"positive and bounded radius");
  I c{0,0},l{C[i][33]*M*K-x[i]*M2,C[i][33]*M*K-x[i]*M2};
  Z b=0,sh=0,sv=0;for(int j=0;j<N;j++){
   c=add(c,scale(R[j],C[i][j]));l=add(l,scale(A[i][j],x[j]));Z w=mag(A[i][j]);b+=w;sh+=w*h[j];sv+=w*v[j];
  }
  Z n=M2*h[i]-K*mag(c)-sh, lin=M2*v[i]-mag(l)-sv, row=529*M2-1000*b;
  req(n>0,"nonlinear");req(lin>0,"linear");req(row>0,"row norm");
  Z dh=M2*h[i],dv=M2*v[i];
  req(1000*sh<226*dh && 1000*sv<160*dv,"weighted norm");
  if(sh*whd>whn*dh){whn=sh;whd=dh;}
  if(sv*wvd>wvn*dv){wvn=sv;wvd=dv;}
  if(i==0||n<mn)mn=n;
  if(i==0||lin<ml)ml=lin;
  if(i==0||row<mr)mr=row;
 }
 std::string extra;req(!(std::cin>>extra),"trailing input");
 std::cout<<"PASS 105 raw integer inequalities\nnonlinear_margin_num "<<mn<<"\nlinear_margin_num "<<ml<<"\nmargin_den "<<M2*K<<"\nrow_margin_num "<<mr<<"\nrow_margin_den "<<1000*M2<<"\nweighted_h_num "<<whn<<"\nweighted_h_den "<<whd<<"\nweighted_v_num "<<wvn<<"\nweighted_v_den "<<wvd<<"\n";
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
