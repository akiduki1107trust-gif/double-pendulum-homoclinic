# Reproduce CP69-R

Requirements Python 3.13 (stdlib for main DAG; SymPy for symbolic checks), C++17 compiler and Boost multiprecision headers. No Lean installation assumed.

1. Extract ZIP; run `python cp69r_replay.py HOMOCLINIC_CP69Q_2026-11-21_研究資料.zip > replay.json` in its root. It checks original nested hashes and raw data, verifies all 2,976 long steps, builds/runs the C++ verifier, checks 105+70 integer bounds, runs 8 rejection tests and independent symbolic comparison. Compare replay.json to CP69R_RESULT.json. (Final C++ expression-template-off version independently compiled and rerun; same arithmetic fields.)
2. Extract the parent Q ZIP separately, run `python CP69Q_VERIFY.py --all` in its CP69Q directory for local initial/C²/C⁰ and geometry checks. The full command was cut off by the tool time limit after all local jobs passed in CP69-R; separate `python CP69Q_VERIFY.py` finished all final gates. Logs for both are included. Parent Q also preserves prior complete local executions.
3. Full code-to-real formal refinement and external independent review remain open. `CP69R_THEOREMS.md` gives source-level classical soundness and weighted contraction proof. Use assertions enabled (not -O). Parent Q contains uncompiled Lean finite arithmetic draft.
