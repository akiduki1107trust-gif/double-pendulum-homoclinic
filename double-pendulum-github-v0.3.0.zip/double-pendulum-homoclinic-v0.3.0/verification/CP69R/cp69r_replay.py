"""Bind CP69-Q and nested raw data, run both independent numerical checks.
No inherited output interval or proof majorant is synthesized here.
"""
import sys, json, hashlib, zipfile, io, tempfile, subprocess, concurrent.futures, shutil
from fractions import Fraction as Q
from pathlib import Path
from cp69r_dag import check
if not __debug__:raise RuntimeError('no -O')
P=Path(__file__).resolve().parent
SHAQ='b6c3788811091a25905bd85eed8c4375b856bd26d73636d808a4437db0891ce1'
SHAP='32d3694d04310de30e26ef5dd156787765443dca0458580d0418133170abf41a'
SHAM='6b719babc0e1f71a8a38503584982003f88e5dce1ce28fa6d4347e71bc04285b'
SHAL='b8890a5f90ac9d5802a6563590da8c952875ecb8515ca12e266d3a5a6b4b82f0'
sha=lambda x:hashlib.sha256(x).hexdigest()
def zap(b,expected=None):
 if expected:assert sha(b)==expected
 z=zipfile.ZipFile(io.BytesIO(b));assert z.testzip() is None;return z
def one(z,suffix):
 names=[n for n in z.namelist() if n.endswith(suffix)];assert len(names)==1,(suffix,names);return z.read(names[0])
def manifest(z,suffix):
 n=next(n for n in z.namelist() if n.endswith(suffix));base=n.rsplit('/',1)[0]+'/';m=json.loads(z.read(n));assert isinstance(m,dict)
 for file,h in m.items():assert sha(z.read(base+file))==h,file
 return len(m)
def sources(qpath):
 q=zap(qpath.read_bytes(),SHAQ);qcount=manifest(q,'CP69Q/SHA256.json');p=zap(one(q,'HOMOCLINIC_CP69P_2026-11-20_研究資料.zip'),SHAP);pcount=manifest(p,'CP69P/SHA256.json')
 o=zap(one(p,'HOMOCLINIC_CP69O_2026-11-20_研究資料.zip'),'042317b13e16e0c89d2550f90a576c0e82bbd4fb09210d91c6c2ac318a24c0bf')
 n=zap(one(o,'UPSTREAM_CP69N_2026-11-20.zip'),'6816815984eb232da14755dff719dd9c68d69f8b1ff415ed887eed2421e93af8')
 m=zap(one(n,'UPSTREAM_CP69M_2026-11-19.zip'),SHAM);l=zap(one(m,'UPSTREAM_CP69L_2026-11-19.zip'),SHAL)
 c0=one(l,'CP69L_RATIONAL8D_1488STEP_WITNESS.json');assert sha(c0)=='16f4fc38662b16a490d731fde726046ee62d29afadc6a0fb9cc48d8592705b74'
 c1=[one(m,f'CP69M_24D/cp69m_24d_{i:02d}_124.json') for i in range(12)]
 return q,o,c0,c1,qcount,pcount

def run(qpath):
 q,o,c0,c1,qcount,pcount=sources(qpath)
 with tempfile.TemporaryDirectory(prefix='CP69R-') as td:
  t=Path(td);qdir=t/'Q';qdir.mkdir()
  for n in ('CP69Q_NEW_PHYSICAL35D.json','CP69Q_FRACTION_FINAL_RESULT.json','CP69Q_FINITE_CONTRACTION.json'):(qdir/n).write_bytes(one(q,'CP69Q/'+n))
  sens=t/'sensitivity.json';sens.write_bytes(one(o,'CP69O_SENSITIVITY_RESULT.json'))
  d0=t/'c0.json';d0.write_bytes(c0);ds=[]
  for i,b in enumerate(c1):d=t/f'c1_{i:02}.json';d.write_bytes(b);ds.append(d)
  # Fixed inputs, shape, exact 12 x 124. Hashes bind to parent geometry.
  assert len(json.loads(c0)['records'])==1488
  jobs=[(d0,8,list(range(12)))]+[(f,24,[i]) for i,f in enumerate(ds)]
  def job(x):
   f,n,ns=x;r=subprocess.run([sys.executable,str(P/'cp69r_dag.py'),str(f),str(n),*map(str,ns)],capture_output=True,text=True,check=True)
   return [json.loads(l) for l in r.stdout.splitlines()]
  with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:rs=[r for a in ex.map(job,jobs) for r in a]
  assert len(rs)==24 and sum(r['steps'] for r in rs)==2976
  assert sum(r['picard_conditions']+r['taylor_conditions'] for r in rs)==95232
  inp=subprocess.check_output([sys.executable,str(P/'cp69r_input.py'),str(qdir),str(sens)])
  exe=t/'finite';subprocess.run(['g++','-O2','-std=c++17',str(P/'cp69r_finite.cpp'),'-o',str(exe)],check=True)
  output=subprocess.check_output([str(exe)],input=inp,text=False).decode()
  ls=output.splitlines();assert ls[0]=='PASS 105 raw integer inequalities';f=dict(x.split() for x in ls[1:]);f={k:int(v) for k,v in f.items()}
  pfinal=json.loads((qdir/'CP69Q_FRACTION_FINAL_RESULT.json').read_text());assert Q(f['nonlinear_margin_num'],f['margin_den'])==Q(pfinal['nonlinear_margin']);assert Q(f['linear_margin_num'],f['margin_den'])==Q(pfinal['linear_margin']);assert Q(529,1000)-Q(f['row_margin_num'],f['row_margin_den'])==Q(pfinal['theta']);assert Q(f['weighted_h_num'],f['weighted_h_den'])<Q(226,1000) and Q(f['weighted_v_num'],f['weighted_v_den'])<Q(160,1000)
  # Actual independent checker negative tests, targeted invalid conditions.
  import copy
  c=json.loads(c1[0])['records'];tests=[]
  for label,mut in [('phase',lambda a:a[0]['input_x'].__setitem__(4,['0','0'])),('Picard',lambda a:a[0]['picard_B'].__setitem__(0,['0','0'])),('Taylor',lambda a:a[0]['output_x'].__setitem__(0,['0','0'])),('chain',lambda a:a[1]['input_x'].__setitem__(0,['0','0'])),('identity',lambda a:a[0]['input_V'][0].__setitem__(0,['0','0']))]:
   a=copy.deepcopy(c);mut(a)
   try:check(a,24,0)
   except AssertionError as e:
    if label in ('phase','Picard','Taylor'):assert e.args and e.args[0][0]==label,(label,e.args)
    tests.append(label)
   else:raise AssertionError('mutation accepted '+label)
  # Wrong final source residual and zero h; positions determined by fixed input schema.
  tok=inp.split();off=4+35**2+2*35**2
  for label,idx,val in [('residual',off,b'99999999999999999999999999999999999999999999999999999999999'),('zero radius',off+70,b'0'),('correction',2,b'0')]:
   bad=tok.copy();bad[idx]=val;rr=subprocess.run([str(exe)],input=b'\n'.join(bad),capture_output=True);assert rr.returncode!=0;tests.append(label)
  symbolic=subprocess.check_output([sys.executable,str(P/'cp69r_symbolic.py')],text=True);assert symbolic.count('PASS')==2
  out={'status':'PASS','parent_sha256':SHAQ,'manifest_Q_P':[qcount,pcount],'raw_C0_sha256':sha(c0),'raw_C1_sha256':[sha(x) for x in c1],'step_results':rs,'long_steps':2976,'long_conditions':95232,'finite_conditions':105,'weighted_conditions':70,'finite_result':{k:str(v) for k,v in f.items()},'mutations_rejected':tests,'symbolic_result':symbolic.splitlines(),'lean_compiled':False}
  print(json.dumps(out,indent=2))
if __name__=='__main__':run(Path(sys.argv[1]))
