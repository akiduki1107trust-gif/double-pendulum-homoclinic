"""Export raw interval, not Q's precomputed majorant; exact rational conversion only."""
import sys,json
from pathlib import Path
from fractions import Fraction as Q
if not __debug__:raise RuntimeError('no -O')
P=Path(sys.argv[1]);O=Path(sys.argv[2]);m=10**45;k=10**30
r=json.loads((P/'CP69Q_NEW_PHYSICAL35D.json').read_text());f=json.loads((P/'CP69Q_FRACTION_FINAL_RESULT.json').read_text());g=json.loads(O.read_text());assert r['scale']==m and r['dimension']==35
h=list(map(Q,f['nonlinear_radii']));v=list(map(Q,g['radius']));x=list(map(Q,g['center']));assert len(h)==len(v)==len(x)==35
out=[m,k,m*Q('8.486')*Q('1.725e-13'),m*Q('8.486')*Q('1.542e-8')]
for row in r['C']:
 for a,b in row:assert a==b;out.append(int(a))
for row in r['J']:
 for a,b in row:out.extend(map(int,(a,b)))
for a,b in r['residual']:out.extend(map(int,(a,b)))
for vec in (h,v,x):out.extend(k*y for y in vec)
assert all(Q(t).denominator==1 for t in out)
print('\n'.join(str(int(t)) for t in out))
