"""Independent incremental coefficient DAG for lifted rational 8D/24D equations."""
import sys,json
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
if not __debug__:raise RuntimeError('assertions required')
S=10**55;K=10**10
Z=(0,0)
def iv(q):
 q=Q(q)*S;return q.numerator//q.denominator,-((-q.numerator)//q.denominator)
def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[1],-a[0]
def mul(a,b):
 v=[x*y for x in a for y in b];return min(v)//S,-((-max(v))//S)
def inv(a):
 assert a[0]>0 or a[1]<0;return S*S//a[1],-((-S*S)//a[0])
def isum(xs):
 lo=hi=0
 for a,b in xs:lo+=a;hi+=b
 return lo,hi
def load(z):
 assert len(z)==2;a,b=map(int,z);assert a<=b;return a*K,b*K
def margin(a,b):return min(b[0]-a[0],a[1]-b[1])
def trig(a,p):
 m=Q(a[0]+a[1],2*S);w=Q(a[1]-a[0],2*S)
 t=sum(((-1)**k*m**(2*k+p)/factorial(2*k+p) for k in range(51)),Q(0));r=abs(m)**(101+p)/factorial(101+p)+w
 return iv(t-r)[0],iv(t+r)[1]
class E:
 def __init__(self,d,i):self.d=d;self.i=i
 def __add__(s,t):return s.d.op('add',s,t)
 __radd__=__add__
 def __neg__(s):return s.d.op('neg',s)
 def __sub__(s,t):return s+-s.d.val(t)
 def __rsub__(s,t):return s.d.val(t)+-s
 def __mul__(s,t):return s.d.op('mul',s,t)
 __rmul__=__mul__
 def __truediv__(s,t):return s*s.d.op('inv',t)
class DAG:
 def __init__(self,n):self.n=n;self.ops=[('var',i) for i in range(n)];self.cache={};self.x=[E(self,i) for i in range(n)]
 def put(self,k):
  if k not in self.cache:self.cache[k]=len(self.ops);self.ops.append(k)
  return E(self,self.cache[k])
 def val(self,v):return v if isinstance(v,E) else self.put(('const',iv(v)))
 def op(self,tag,*p):
  p=[self.val(t).i for t in p]
  if tag in ('add','mul'):
   z=self.val(0).i;o=self.val(1).i
   if z in p:return E(self,z if tag=='mul' else p[1-p.index(z)])
   if tag=='mul' and o in p:return E(self,p[1-p.index(o)])
  return self.put((tag,*p))
 def field(self):
  _,_,p,q,s,c,t,d=self.x[:8];C=c*d+s*t;D=s*d-c*t;self.cd=(C.i,D.i);den=2-C*C;u=(p-C*q)/den;v=(2*q-C*p)/den;cross=D*u*v
  out=[u,v,-cross-2*s,cross-t,c*u,-s*u,d*v,-t*v]
  if self.n==24:
   J=[[] for _ in range(4)]
   for j in range(4):
    ck=[-D,D,0,0][j];dk=[C,-C,0,0][j]
    du=(int(j==2)-C*int(j==3)-q*ck+2*C*u*ck)/den
    dv=(2*int(j==3)-C*int(j==2)-p*ck+2*C*v*ck)/den
    dw=dk*u*v+D*du*v+D*u*dv
    for i,z in enumerate([du,dv,-dw-2*c*int(j==0),dw-d*int(j==1)]):J[i].append(z)
   out += [sum(J[i][l]*self.x[8+4*l+j] for l in range(4)) for i in range(4) for j in range(4)]
  return [t.i for t in out]
 def jet(self,x,n,roots):
  ts=[[z] for z in x]+[[] for _ in self.ops[self.n:]]
  for k in range(n):
   for i,op in enumerate(self.ops[self.n:],self.n):
    tag,*p=op
    if tag=='const':z=p[0] if k==0 else Z
    elif tag=='add':z=add(ts[p[0]][k],ts[p[1]][k])
    elif tag=='neg':z=neg(ts[p[0]][k])
    elif tag=='mul':z=isum(mul(ts[p[0]][j],ts[p[1]][k-j]) for j in range(k+1))
    elif tag=='inv':
     a=ts[p[0]];z=inv(a[0]) if k==0 else neg(mul(ts[i][0],isum(mul(a[j],ts[i][k-j]) for j in range(1,k+1))))
    else:raise ValueError(tag)
    ts[i].append(z)
   for i,r in enumerate(roots):
    a,b=ts[r][k];ts[i].append((a//(k+1),-((-b)//(k+1))))
  return ts[:self.n]
def flat(x):return [z for row in x for z in row]
def arrays(r,n):
 if n==8:return [[load(z) for z in r[k]] for k in ['input8','picard8','output8']]
 return [[load(z) for z in r[k]+flat(r[v])] for k,v in [('input_x','input_V'),('picard_B','picard_VB'),('output_x','output_V')]]
def check(records,n,node):
 d=DAG(n);roots=d.field();assert len(roots)==n;prev=None;mp=mt=None
 for k,r in enumerate(records):
  assert r['node']==node and r['step']==k and Q(r['h'])==Q('.00990902423360074')
  X,B,Y=arrays(r,n);assert len(X)==len(B)==len(Y)==n
  if k==0:
   for i,j,p in [(4,0,1),(5,0,0),(6,1,1),(7,1,0)]:assert margin(X[i],trig(X[j],p))>=0,('phase',node,i)
   if n==24:assert X[8:]==[iv(int(i==j)) for i in range(4) for j in range(4)]
  else:assert X==prev
  prev=Y;h=Q(r['h']);o=int(r['degree']);assert 1<=o<=12
  F=d.jet(B,1,roots);H=(0,iv(h)[1]);P=[add(X[i],mul(H,F[i][1])) for i in range(n)]
  m=min(margin(B[i],P[i]) for i in range(n));assert m>0,('Picard',n,node,k,m);mp=m if mp is None else min(mp,m)
  A=d.jet(X,o,roots);T=d.jet(B,o+1,roots);powers=[iv(h**j) for j in range(o+2)]
  result=[add(isum(mul(A[i][j],powers[j]) for j in range(o+1)),mul(T[i][o+1],powers[o+1])) for i in range(n)]
  m=min(margin(Y[i],result[i]) for i in range(n));assert m>=0,('Taylor',n,node,k,m);mt=m if mt is None else min(mt,m)
 assert len(records)==124
 return dict(node=node,dimension=n,steps=len(records),dag_nodes=len(d.ops),picard_conditions=n*len(records),taylor_conditions=n*len(records),min_picard_margin=str(Q(mp,S)),min_taylor_margin=str(Q(mt,S)))
if __name__=='__main__':
 p=Path(sys.argv[1]);n=int(sys.argv[2]);doc=json.loads(p.read_text());ns=list(map(int,sys.argv[3:])) or list(range(12))
 for node in ns:
  rs=[r for r in doc['records'] if r['node']==node];out=check(rs,n,node);print(json.dumps(out),flush=True)
