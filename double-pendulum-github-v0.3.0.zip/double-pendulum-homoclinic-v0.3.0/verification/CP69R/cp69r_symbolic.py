"""Compare actual DAG roots against Hamiltonian derivatives, with C,D kept symbolic."""
import sympy as s
from cp69r_dag import DAG,S
if not __debug__:raise RuntimeError('no -O')
x=s.symbols('q1 q2 p1 p2 s1 c1 s2 c2');V=s.Matrix(4,4,s.symbols('v0:16'));q1,q2,p,q,si,ci,ti,di=x
C,D=s.symbols('C D');H=(p*p-2*C*p*q+2*q*q)/(2*(2-C*C))-2*ci-di
def deriv(f,j):
 if j==0:return -D*s.diff(f,C)+C*s.diff(f,D)+ci*s.diff(f,si)-si*s.diff(f,ci)
 if j==1:return D*s.diff(f,C)-C*s.diff(f,D)+di*s.diff(f,ti)-ti*s.diff(f,di)
 return s.diff(f,x[j])
f=[deriv(H,2),deriv(H,3),-deriv(H,0),-deriv(H,1)];f=list(map(s.cancel,f))
expected=f+[ci*f[0],-si*f[0],di*f[1],-ti*f[1]]
J=s.Matrix(4,4,lambda i,j:s.cancel(deriv(f[i],j)))
for n in (8,24):
 dag=DAG(n);roots=dag.field();v=list(x)+(list(V) if n==24 else [])
 for i,op in enumerate(dag.ops[n:],n):
  tag,*p=op
  if tag=='const':assert p[0][0]==p[0][1];z=s.Rational(p[0][0],S)
  elif tag=='add':z=v[p[0]]+v[p[1]]
  elif tag=='neg':z=-v[p[0]]
  elif tag=='mul':z=v[p[0]]*v[p[1]]
  elif tag=='inv':z=1/v[p[0]]
  else:raise AssertionError(tag)
  if i in dag.cd:
   assert s.expand(z-(ci*di+si*ti if i==dag.cd[0] else si*di-ci*ti))==0
   z=C if i==dag.cd[0] else D
  v.append(z)
 ref=expected+(list(J*V) if n==24 else [])
 for i,(r,a) in enumerate(zip(roots,ref)):
  assert s.cancel(v[r]-a)==0,(n,i)
 print('PASS independent differentiated Hamiltonian graph',n,len(dag.ops),len(roots),flush=True)
