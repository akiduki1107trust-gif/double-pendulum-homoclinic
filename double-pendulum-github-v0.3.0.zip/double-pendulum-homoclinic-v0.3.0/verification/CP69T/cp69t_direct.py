"""CP69-T: direct true-graph tangent enclosure, direct chart sign checks,
independent exact Fraction intervals with outward rational-grid rounding.
Run from extracted immutable evidence; does not import preceding checkers.
All decimals in hypotheses are exact rational strings. No floating arithmetic.
"""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json, zipfile, io, hashlib, sys
if not __debug__: raise RuntimeError('assertions required')
M=10**55; S=10**45
P=Path(__file__).resolve().parent

def down(x): return Q(x*M//1,M)
def up(x): return -down(-x)
class I:
    __slots__=('a','b')
    def __init__(self,a,b=None):
        self.a=down(Q(a)); self.b=up(Q(a if b is None else b)); assert self.a<=self.b
    def __add__(s,t):
        t=iv(t); return I(s.a+t.a,s.b+t.b)
    __radd__=__add__
    def __neg__(s): return I(-s.b,-s.a)
    def __sub__(s,t): return s+-iv(t)
    def __rsub__(s,t): return iv(t)+-s
    def __mul__(s,t):
        t=iv(t); x=[s.a*t.a,s.a*t.b,s.b*t.a,s.b*t.b]; return I(min(x),max(x))
    __rmul__=__mul__
    def __truediv__(s,t):
        t=iv(t); assert t.a*t.b>0; return s*I(1/t.b,1/t.a)
    def __rtruediv__(s,t): return iv(t)/s
    def mag(s):return max(abs(s.a),abs(s.b))
    def has(s,t):t=iv(t); return s.a<=t.a<=t.b<=s.b
    def meet(s,t):return I(max(s.a,t.a),min(s.b,t.b))
    def pair(s):return [str(s.a),str(s.b)]
def iv(t):return t if isinstance(t,I) else I(t)
def pm(t):return I(-t,t)
def load(t):return I(Q(int(t[0]),S),Q(int(t[1]),S))
def trig(x,k):
    # Taylor at exact rational midpoint, independent derivative Lipschitz inflation.
    m=(x.a+x.b)/2; r=(x.b-x.a)/2
    def pt(p):
        a=sum(((-1)**j*m**(2*j+p)/factorial(2*j+p) for j in range(51)),Q(0))
        e=abs(m)**(101+p)/factorial(101+p)
        return a,e
    a,e=pt(k);d,de=pt(1-k);e+=r*min(Q(1),abs(d)+de+r)
    return I(max(-1,a-e),min(1,a+e))
def sin(x):return trig(x,1)
def cos(x):return trig(x,0)
def field(z):
    a,b,p,q=z;c=cos(a-b);s=sin(a-b);den=2-c*c
    u=(p-c*q)/den;v=(2*q-c*p)/den;cross=s*u*v
    return [u,v,-cross-2*sin(a),cross-sin(b)]
def grad(z):
    f=field(z);return [-f[2],-f[3],f[0],f[1]]
def jac(z):
    a,b,p,q=z;c=cos(a-b);s=sin(a-b);den=2-c*c
    u=(p-c*q)/den;v=(2*q-c*p)/den;ca=cos(a);cb=cos(b)
    cols=[]
    for k in range(4):
        ck=[-s,s,0,0][k];sk=[c,-c,0,0][k]
        du=(int(k==2)-c*int(k==3)-q*ck+2*c*u*ck)/den
        dv=(2*int(k==3)-c*int(k==2)-p*ck+2*c*v*ck)/den
        dw=sk*u*v+s*(du*v+u*dv)
        cols.append([du,dv,-dw-2*ca*int(k==0),dw-cb*int(k==1)])
    return [list(r) for r in zip(*cols)]
def energy(z):
    a,b,p,q=z;c=cos(a-b);return (p*p-2*c*p*q+2*q*q)/(2*(2-c*c))-2*cos(a)-cos(b)+Q('.9')
def energy_mvt(z):
    mid=[I((x.a+x.b)/2) for x in z]
    # Both center and full box are grid intervals; integrate gradient along segment.
    # A half-grid midpoint can round outward, so use a grid endpoint instead.
    mid=[I(x.a) for x in mid]
    assert all(x.has(y) for x,y in zip(z,mid))
    return energy(mid)+sum(g*(x-y) for g,x,y in zip(grad(z),z,mid))
def signroot(box,e):
    gg=grad(box)[e];assert gg.a>0 or gg.b<0
    a=list(box);b=list(box);a[e]=I(box[e].a);b[e]=I(box[e].b)
    A=energy(a).meet(energy_mvt(a));B=energy(b).meet(energy_mvt(b))
    # Return a strictly positive *uniform endpoint sign* margin or a failure.
    margin=min(-A.b,B.a) if gg.a>0 else min(-B.b,A.a)
    assert margin>0,('root signs',e,str(margin))
    return margin

def zipb(b):return zipfile.ZipFile(io.BytesIO(b))
def get(z,s):
    names=[n for n in z.namelist() if n.endswith(s)];assert len(names)==1,(s,names);return z.read(names[0])
def readj(z,s):return json.loads(get(z,s))
def hsh(b):return hashlib.sha256(b).hexdigest()
def run(evidence):
    b=Path(evidence).read_bytes();assert hsh(b)=='81fea80b10873aedc354679ce7307f04d9df76d57374e06c9fe83a2cf61b624a'
    r=zipb(b);q=zipb(get(r,'HOMOCLINIC_CP69Q_2026-11-21_研究資料.zip'));p=zipb(get(q,'HOMOCLINIC_CP69P_2026-11-20_研究資料.zip'));o=zipb(get(p,'HOMOCLINIC_CP69O_2026-11-20_研究資料.zip'));n=zipb(get(o,'UPSTREAM_CP69N_2026-11-20.zip'));m=zipb(get(n,'UPSTREAM_CP69M_2026-11-19.zip'));l=zipb(get(m,'UPSTREAM_CP69L_2026-11-19.zip'));d=zipb(get(o,'UPSTREAM_CP69D_2026-11-18.zip'))
    a=readj(d,'cp38_node0_proxy_anchor.json');nodes=[a]+readj(d,'cp34_node_anchors.json');assert len(nodes)==12 and [nd['node'] for nd in nodes]==list(range(12)) and a['e']==0
    graph=readj(q,'CP69Q_GRAPH_RESULT.json');final=readj(q,'CP69Q_FRACTION_FINAL_RESULT.json');sens=readj(o,'CP69O_SENSITIVITY_RESULT.json');raw=readj(q,'CP69Q_NEW_PHYSICAL35D.json')
    c0raw=get(l,'CP69L_RATIONAL8D_1488STEP_WITNESS.json');c0=json.loads(c0raw)['records'];rr=readj(r,'CP69R_RESULT.json');assert hsh(c0raw)==rr['raw_C0_sha256'] and len(c0)==1488
    U0=Q(a['constructing_u']);H2=Q(a['constructing_h2']);P0=Q('.8242999233');Q0=Q('.5661533683');b0=Q('3.3447126987001807');assert H2==Q('-.0026488571962644')
    r0=Q('1e-7');wide=Q(1,2200);d0=Q('1e-15');t0=Q('14.7446280595979');hstep=Q('.00990902423360074');delta=t0/12-124*hstep;dt=r0/12+abs(delta);fudge=100*dt*20/(1-100*dt)
    assert t0-r0>0 and 0<100*dt<1
    assert Q(graph['graph_transform_lip'])<1 and Q(graph['inverse_base_lip'])<1
    assert Q(graph['coverage_left'])>Q('4e-5') and Q(graph['coverage_right'])<-Q('4e-5')
    assert Q(graph['fixed_reflection_u_bound'])<Q('1.634e-6') and Q(graph['fixed_reflection_v_bound'])<Q('3.5e-13')
    assert Q('24.6405')-Q(graph['Y_v_bound'])>Q('24.5')+1/Q('24.5')
    U=I(U0-r0,U0+r0);H=Q(graph['graph_height']);L=Q(graph['graph_slope']);V=pm(H);slope=pm(L)
    assert U.a>Q('1.634e-6') and U.b<Q('4e-5') and H<Q('3.5e-13') and L<Q('2e-8')
    E0=Q('1.725e-13');assert H>0 and L>0
    def state(u,v):return b0+P0*(u+v+H2*u*u), Q0*(u-v-H2*u*u)
    def polyd(u,vp):return P0*(1+vp+2*H2*u), Q0*(1-vp-2*H2*u)
    info=[];D=[];W=[];F=[];CE=[];B=[];CEN=[]
    for i,nd in enumerate(nodes):
        c=list(map(Q,nd['center']));CEN.append(c);e=nd['e'];keep=[j for j in range(4) if j!=e]
        dat=get(m,f'CP69M_24D/cp69m_24d_{i:02d}_124.json');assert hsh(dat)==rr['raw_C1_sha256'][i];rec=json.loads(dat)['records'];cr=[z for z in c0 if z['node']==i];assert len(rec)==len(cr)==124
        for k,(a1,a0) in enumerate(zip(rec,cr)):
            assert a1['node']==a0['node']==i and a1['step']==a0['step']==k and Q(a1['h'])==Q(a0['h'])==hstep
            if k:assert a1['input_x']==rec[k-1]['output_x'] and a1['input_V']==rec[k-1]['output_V'] and a0['input8']==cr[k-1]['output8']
        box1=[load(x) for x in rec[0]['input_x'][:4]];box0=[load(x) for x in cr[0]['input8'][:4]]
        wb=[I(c[k]-wide,c[k]+wide) for k in range(4)];wg=grad(wb);assert wg[e].a>0 or wg[e].b<0
        assert all(t.has(x) for t,x in zip(wb,box1))
        # Exact center of shooting coordinates, not rounded full state.
        cbox=[I(x) for x in c];cbox[e]=I(c[e]-d0,c[e]+d0)
        if i==0:cbox[1],cbox[3]=state(I(U0),I(0));cbox[2]=I(0)
        cm=signroot(cbox,e);assert all(x.has(y) for x,y in zip(box0,cbox)) and all(x.has(y) for x,y in zip(box1,cbox))
        # Direct bracket signs on the actual uniform C1 input range. Narrower retained coordinates.
        phys=[I(c[k]-r0,c[k]+r0) for k in range(4)];phys[e]=box1[e]
        if i==0:phys[1],phys[3]=state(U,V);phys[2]=I(0);assert Q('.347')<phys[0].a<=phys[0].b<Q('.351')
        um=signroot(phys,e);assert all(x.has(y) for x,y in zip(box1,phys))
        # Optional root tightening: use interval mean value along eliminated coordinate at center c[e].
        mid=list(phys);mid[e]=I(c[e]);assert phys[e].has(mid[e]);er=energy(mid).meet(energy_mvt(mid));gp=grad(phys)[e];tight=I(c[e])-er/gp;phys[e]=phys[e].meet(tight)
        # Bound each true input vs exact proxy/node center; no sparse tangent correction.
        ds=[(x-y).mag() for x,y in zip(phys,cbox)]
        gg=grad(phys)
        if i==0:
            mv=max(P0,Q0, (-(gg[1]*P0-gg[3]*Q0)/gg[0]).mag());assert mv*H<E0
            dq2,dp2=polyd(U,slope);D.append([[-(gg[1]*dq2+gg[3]*dp2)/gg[0]],[dq2],[I(0)],[dp2]])
        else:D.append([[I(int(k==j)) if k!=e else -gg[j]/gg[e] for j in keep] for k in range(4)])
        W0=[[load(x) for x in row] for row in rec[-1]['output_V']];wn=max(sum(x.mag() for x in row) for row in W0);assert wn<20
        ce=[load(x) for x in cr[-1]['output8'][:4]];y=[load(x) for x in rec[-1]['output_x'][:4]]
        spread=[(ce[k]+sum(W0[k][j]*pm(ds[j]) for j in range(4))).meet(y[k]) for k in range(4)]
        tube=[v+pm(Q('1e-5')) for v in spread];f=field(tube);A=jac(tube);fn=max(x.mag() for x in f);an=max(sum(x.mag() for x in row) for row in A);assert fn<100 and an<100 and dt*fn<Q('1e-5')
        ws=[[x+pm(fudge) for x in row] for row in W0]
        # For center residual, the same state tube might not cover the proxy initial point if not in true graph box.
        # Prove that separately with the union of actual- and proxy-center endpoints using ce.
        both=[(I(min(t.a,v.a),max(t.b,v.b)))+pm(Q('1e-5')) for t,v in zip(spread,ce)];fb=field(both);Ab=jac(both);assert max(x.mag() for x in fb)<100 and max(sum(x.mag() for x in row) for row in Ab)<100
        assert dt*max(x.mag() for x in fb)<Q('1e-5')
        # If origin-to-true center line is used for E0, its entire initial segment lies in the common input box.
        if i==0:
            all_tube=[v+pm(Q('1e-5')) for v in y]; fa=field(all_tube);ja=jac(all_tube)
            assert dt*max(x.mag() for x in fa)<Q('1e-5') and max(sum(x.mag() for x in row) for row in ja)<100
            assert wn/(1-100*dt)<Q('8.486')
        W.append(ws);F.append(f);CE.append([x+delta*v for x,v in zip(ce,fb)]);B.append(tube)
        if i<11:
            nxt=list(map(Q,nodes[i+1]['center']));assert all(I(x-wide,x+wide).has(v) for x,v in zip(nxt,tube))
        info.append({'node':i,'center_sign_margin':str(cm),'uniform_sign_margin':str(um),'tight_input': [x.pair() for x in phys],'time_exit_margin':str(Q('1e-5')-dt*fn),'max_initial_displacement':str(max(ds))})
    # Machin identity, alternating series, exact rational outward interval.
    def arctan(k):
        v=sum(((-1)**j*Q(1,(2*j+1)*k**(2*j+1)) for j in range(100)),Q(0));return I(v,v+Q(1,201*k**201))
    pi=16*arctan(5)-4*arctan(239)
    J=[[I(0) for j in range(35)] for i in range(35)];res=[I(0) for i in range(35)]
    for i in range(12):
        keep=[0,1] if i==11 else [k for k in range(4) if k!=nodes[i+1]['e']]
        for w,k in enumerate(keep):
            row=3*i+w;J[row][1]=F[i][k]/12
            for j in range(len(D[i][0])):J[row][0 if i==0 else 2+3*(i-1)+j]=sum(W[i][k][l]*D[i][l][j] for l in range(4))
            if i<11:J[row][2+3*i+w]=I(-1)
            res[row]=CE[i][k]-(CEN[i+1][k] if i<11 else I(0) if k==0 else 2*pi)
            if i==0:res[row]+=pm(Q('8.486')*E0)
    C=[[load(x) for x in row] for row in raw['C']];assert len(C)==35 and all(len(row)==35 for row in C);assert all(x.a==x.b for row in C for x in row)
    AA=[[int(i==j)-sum(C[i][k]*J[k][j] for k in range(35)) for j in range(35)] for i in range(35)]
    BB=[[x.mag() for x in row] for row in AA];aa=[sum(C[i][k]*res[k] for k in range(35)).mag() for i in range(35)]
    radii=list(map(Q,final['nonlinear_radii']));v=list(map(Q,sens['radius']));z=list(map(Q,sens['center']))
    assert len(radii)==len(v)==len(z)==35
    def bmul(i,h):return sum(BB[i][j]*h[j] for j in range(35))
    margin=min(radii[i]-aa[i]-bmul(i,radii) for i in range(35));print('existence margin',float(margin),flush=True);assert margin>0 and all(0<x<r0 for x in radii)
    lr=[(C[i][33]+sum(AA[i][j]*z[j] for j in range(35))-z[i]).mag() for i in range(35)]
    lm=min(v[i]-lr[i]-bmul(i,v) for i in range(35));print('linear margin',float(lm),flush=True);assert lm>0 and min(v)>0
    Z=[I(x-y,x+y) for x,y in zip(z,v)];s=F[-1][2]/12*Z[1]+sum(sum(W[-1][2][k]*D[-1][k][j] for k in range(4))*Z[32+j] for j in range(3))
    assert F[-1][1].a>Q('.74006') and Q('.35295')<s.a<=s.b<Q('.68516')
    bad=[(C[i][34]+sum(AA[i][j]*z[j] for j in range(35))-z[i]).mag() for i in range(35)]
    assert any(v[i]-bad[i]-bmul(i,v)<0 for i in range(35))
    assert any(x>0 for x in aa) # zero-radius inclusion would fail
    assert Q('5.56e-15')<margin and Q('2.84e-7')<lm
    result={'status':'PASS','wrong_rhs_rejected':True,'zero_radius_rejected':True,'evidence_sha256':hsh(b),'nodes':info,'source_Mv':str(mv),'source_E0_direct':str(mv*H),'direct_true_tangent': [x[0].pair() for x in D[0]],'min_center_chart_sign':str(min(Q(x['center_sign_margin']) for x in info)),'min_uniform_chart_sign':str(min(Q(x['uniform_sign_margin']) for x in info)),'nonlinear_margin':str(margin),'linear_margin':str(lm),'theta_h':str(max(bmul(i,radii)/radii[i] for i in range(35))),'theta_v':str(max(bmul(i,v)/v[i] for i in range(35))),'terminal_slope':s.pair(),'terminal_speed':F[-1][1].pair(),'strict_det_lower':str(2*s.a),'J':[[x.pair() for x in row] for row in J],'residual':[x.pair() for x in res]}
    print('slope',float(s.a),float(s.b),'speed',float(F[-1][1].a),float(F[-1][1].b),flush=True)
    return result
if __name__=='__main__':
    result=run(sys.argv[1]);Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n')
