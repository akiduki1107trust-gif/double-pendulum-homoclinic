#!/usr/bin/env python3
"""CP69-T reproduction: direct gate plus authentic prior interval proof.
Default checks all new data/output and bindings. --full also reruns both
complete upstream ODE replays with explicit successful exit checks.
"""
from pathlib import Path
import hashlib, json, subprocess, sys, tempfile, zipfile, io, shutil
if not __debug__: raise RuntimeError('do not run Python -O')
p=Path(__file__).resolve().parent
assert set(sys.argv[1:])<= {'--full'}
for n,s in json.loads((p/'SHA256.json').read_text()).items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==s,n
r=p/'double-pendulum-CP69R-evidence.zip';pub=p/'double-pendulum-github-v0.2.0.zip';s=p/'CP69S_FINAL_AUDIT_2026-11-21.zip'
assert hashlib.sha256(r.read_bytes()).hexdigest()=='81fea80b10873aedc354679ce7307f04d9df76d57374e06c9fe83a2cf61b624a'
assert hashlib.sha256(pub.read_bytes()).hexdigest()=='30635893add05c726a9ed321d429daab9c520cc7c41b572f96cb660189dc3a27'
assert hashlib.sha256(s.read_bytes()).hexdigest()=='fb26f5defb1abd75dd6c075d20fb55652445766e7d53d4bca8f5bf7492d4aa85'
for f in (r,pub,s):
    with zipfile.ZipFile(f) as z:assert z.testzip() is None,f
print('PASS source archive CRC and SHA manifest',flush=True)

def one(z,x):
    ns=[n for n in z.namelist() if n.endswith(x)];assert len(ns)==1,(x,ns);return z.read(ns[0])
def readz(b):return zipfile.ZipFile(io.BytesIO(b))
with tempfile.TemporaryDirectory(prefix='cp69t-') as td:
    t=Path(td)
    with zipfile.ZipFile(pub) as z:
        for m in z.namelist(): assert not Path(m).is_absolute() and '..' not in Path(m).parts
        z.extractall(t)
    root=t/'double-pendulum-homoclinic-v0.2.0';o=t/'direct.json'
    if '--full' in sys.argv:
        for mode in ('local-full','long'):
            subprocess.run([sys.executable,str(root/'verify.py'),str(r),'--mode',mode],check=True)
            print('PASS complete replay',mode,'exit 0',flush=True)
    subprocess.run([sys.executable,str(p/'cp69t_direct.py'),str(r),str(o)],check=True)
    assert o.read_bytes()==(p/'CP69T_DIRECT_RESULT.json').read_bytes()
    assert subprocess.run([sys.executable,'-O',str(p/'cp69t_direct.py'),str(r),str(o)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False).returncode!=0
    print('PASS direct graph tangent, all charts, 35D existence and sensitivity; result bytes identical',flush=True)
    out=subprocess.check_output([sys.executable,str(root/'verification/CP69S/cp69s_cross_bind.py'),str(r)])
    assert out==(p/'T_cross_bind.json').read_bytes()
    q=readz(one(zipfile.ZipFile(r),'HOMOCLINIC_CP69Q_2026-11-21_研究資料.zip'));pr=readz(one(q,'HOMOCLINIC_CP69P_2026-11-20_研究資料.zip'))
    O=one(pr,'HOMOCLINIC_CP69O_2026-11-20_研究資料.zip');H=one(pr,'HOMOCLINIC_CP69H_2026-11-19_研究資料.zip')
    N=readz(one(readz(O),'UPSTREAM_CP69N_2026-11-20.zip'));M=one(N,'UPSTREAM_CP69M_2026-11-19.zip');L=one(readz(M),'UPSTREAM_CP69L_2026-11-19.zip');G=one(readz(H),'UPSTREAM_HOMOCLINIC_CP69G_2026-11-19_研究資料.zip')
    for k,b in zip('OHMLG',(O,H,M,L,G)):(t/f'HOMOCLINIC_CP69{k}_2026_bound.zip').write_bytes(b)
    b=t/'cp69p_bind.py';b.write_bytes(one(pr,'CP69P/cp69p_bind.py'))
    out=subprocess.check_output([sys.executable,str(b),str(t)])
    assert out==(p/'T_bind.json').read_bytes()
    print('PASS both binding checks; result bytes identical',flush=True)
print('PASS CP69-T'+(' complete replay' if '--full' in sys.argv else ' direct and binding replay (full upstream replay optional)')+'; no Lean or external referee claim',flush=True)
