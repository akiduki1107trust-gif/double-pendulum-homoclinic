# CP69-T 再現方法

- Python 3.13.5（Fraction を標準数学的意味で使用）。`--full` には g++ (実行環境 GCC 14.2.0)、Boost multiprecision と SymPy が必要（公開版v0.2.0の requirements.txt 参照）。ネットワーク接続不要。Python -O を使用しない。
- `python CP69T_VERIFY.py` で親 ZIP（R, 公開版 v0.2.0, S）の SHA/CRC・全追加ファイル、T の新しい真接線／中心と全域チャート／35D存在と感度、二つの連結監査を再生し、保存した結果とバイト単位で比較する。
- `python CP69T_VERIFY.py --full` は公開版の `local-full`（初期48ジェット、267+804全局所ステップ、graphまでの全後段）と `long`（2976全長ステップ、175整数条件等）を再実行してから同じ T 検証へ進む。いずれも exit code を捕捉する。
- 今回、公開版の `local-full` と `long` をクリーン展開でそれぞれ実際に実行し **両終了コード0**。`T_local_full.log/.exit`, `T_long.log/.exit` が証拠。新規ラッパーの `--full` は省略し、その各構成処理は個別に実行済み。`CP69T_VERIFY.py` デフォルトは後述の最終ZIP展開で検査。
- `CP69T_DIRECT_RESULT.json` に全1225区間行列・35残差・70収縮条件の最小余裕などを保存。出力する数値の float は表示のみ。原R, 公開版v0.2.0, Sを変更せず同梱。旧QPV追加枝は原アーカイブのSHAを別記し、今回の直接証明には使わない。
- 本資料の普通の計算機援用証明としての数学的接続は `CP69T_COMPLETE_PROOF_JA.md`。外部査読・Lean の全形式化・初出性の認定は未実施。
