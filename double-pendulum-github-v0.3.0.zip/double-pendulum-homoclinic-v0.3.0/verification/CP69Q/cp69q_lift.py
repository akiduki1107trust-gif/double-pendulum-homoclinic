"""Independent full graph energy-lift bound using CP69H's 3-variable Hessian and new scalar kernel."""
import json
from pathlib import Path
from fractions import Fraction as Q
from cp69q_anchor import T,field,variable,jet_from_t,R,C,M,ZERO
if not __debug__:raise RuntimeError('no -O')
P=Path(__file__).resolve().parent
p=Q('.8242999233');q=Q('.5661533683');r=Q('4e-5');eps=Q('3.5e-13')
def span(a,b):return R(C(a).a,C(b).b)
U,V,B=span(-r,r),span(-eps,eps),span(Q('.347'),Q('.351'))
a=field(T(C('.347')),T(U),T(V)).x;b=field(T(C('.351')),T(U),T(V)).x
assert a.b<0<b.a
f=field(variable(B,0),variable(U,1),variable(V,2));assert f.g[0].a>Q('.68')*M
u,v,uu,uv,vv=jet_from_t(f)
mag=lambda x:Q(max(abs(x.a),abs(x.b)),M)
Mv=max(p,q,mag(v));Muv=mag(uv)
g=json.loads((P/'CP69Q_GRAPH_RESULT.json').read_text());E0=Mv*Q(g['graph_height']);E1=Mv*Q(g['graph_slope'])+Muv*Q(g['graph_height'])
assert E0<Q('1.725e-13') and E1<Q('1.649e-8')
out={'status':'PASS','Hq_lower':str(Q(f.g[0].a,M)),'Mv':str(Mv),'Muv':str(Muv),'E0':str(E0),'E1':str(E1),'E0_margin':str(Q('1.725e-13')-E0),'E1_margin':str(Q('1.649e-8')-E1)}
(P/'CP69Q_LIFT_RESULT.json').write_text(json.dumps(out,indent=2));print('PASS lift', {k:float(Q(v)) for k,v in out.items() if k!='status'})
