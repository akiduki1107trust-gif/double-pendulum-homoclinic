#!/usr/bin/env python3
"""CP69-Q: CP69-O graph equations with alternate scalar and parameter-jet kernel."""
import sys,json,gzip,hashlib
from pathlib import Path
from fractions import Fraction as Q
if not __debug__: raise RuntimeError('no -O')
P=Path(__file__).resolve().parent
from cp69q_c2 import D2,R,C,M,decode_records,jets,field_series
from cp69q_new_kernel import sharp,pi_bound
from cp69q_c0 import fpoly

def trig_interval(a,b,kind):return sharp(R(a,b),kind)
def hull(mid,rad):
    rr=C(rad);return C(mid)+R(-rr.b,rr.b)
def full_field(B):return [z[0] for z in field_series([[v] for v in B],0)]
def field_with_jac(B):return [z[0] for z in fpoly([[v] for v in B],0)],None
def taylor_step(inp,B,t,order=6):
    trange=R(0,C(t).b);field=full_field(B)
    for i in range(4):
        for j in range(6):
            assert B[i].v[j].interior(inp[i].v[j])
            assert B[i].v[j].interior(inp[i].v[j]+trange*field[i].v[j])
    A=jets(inp,order);Z=jets(B,order+1)
    return [sum((A[i][k]*C(t**k) for k in range(order+1)),D2(0))+Z[i][order+1]*C(t**(order+1)) for i in range(4)]
D=P/'HOMOCLINIC_CP69D_2026-11-18'
read=lambda p: json.loads(p.read_text())
qbounds=lambda a:[Q(a.a,M),Q(a.b,M)]
mag=lambda a:max(abs(a.a),abs(a.b))/Q(M)
def Rq(a,b):return R(C(a).a,C(b).b)
def pair(a):return list(map(str,qbounds(a)))
# Same start endpoint as CP69K. Independently reconstruct event differential.
source=P/'CP69G'/'c2_traces'/'cp58_trace_part_260_267.json.gz'
raw=source.read_bytes(); expected=read(P/'CP69G'/'CP69G_FINAL_AUDIT.json')['C2_pieces'][-1]['sha256']
assert hashlib.sha256(raw).hexdigest()==expected
tr=json.loads(gzip.decompress(raw));assert tr['end_step']==267
x=decode_records(tr['last']['X']);short=Q('.00166292109741');rads=[2,2,2000,20,2000]
B=[D2([hull(z.v[0].center(),Q('.015'))]+[z.v[i+1]+Rq(-rads[i],rads[i]) for i in range(5)]) for z in x]
X=taylor_step(x,B,short)
delta=Rq(Q('-.00006297109741'),Q('.00006400890259'))
buf=[2,2,100,100,100];B=[D2([z.v[0]+Rq(Q('-.004'),Q('.004'))]+[z.v[j+1]+Rq(-buf[j],buf[j]) for j in range(5)]) for z in X]
FF=full_field(B);E=[z+D2([delta*w for w in g.v]) for z,g in zip(X,FF)]
assert all(B[i].v[j].interior(E[i].v[j]) for i in range(4) for j in range(6))
f=full_field(E);a=E[2].v;vv=f[2].v;speed=vv[0];assert speed.a>Q('.67')*M
assert (X[2].v[0]+R(delta.a,delta.a)*FF[2].v[0]).b<0<(X[2].v[0]+R(delta.b,delta.b)*FF[2].v[0]).a
acc=[2*j[2].v[0] for j in jets(E,2)]
tu=-a[1]/speed;tv=-a[2]/speed
tuu=-(a[3]+2*vv[1]*tu+acc[2]*tu*tu)/speed
tuv=-(a[4]+vv[1]*tv+vv[2]*tu+acc[2]*tu*tv)/speed
tvv=-(a[5]+2*vv[2]*tv+acc[2]*tv*tv)/speed
out=[]
for z,g,ac in zip(E,f,acc):
 z=z.v;g=g.v
 out.append(D2([z[0],z[1]+g[0]*tu,z[2]+g[0]*tv,z[3]+2*g[1]*tu+ac*tu*tu+g[0]*tuu,z[4]+g[1]*tv+g[2]*tu+ac*tu*tv+g[0]*tuv,z[5]+2*g[2]*tv+ac*tv*tv+g[0]*tvv]))
p=Q('.8242999233');q=Q('.5661533683');b0=Q('3.3447126987001807');h=Q('-.0026488571962644')
# S and a fixed lift q2 -> 2*pi-q2. Chart target q1 = -q1.
targetq1=-out[0].v[0];assert Rq(Q('.347'),Q('.351')).interior(targetq1)
A=(D2(2*pi_bound())-out[1]-D2(b0))/(2*D2(p))-out[3]/(2*D2(q))
Bcoord=(D2(2*pi_bound())-out[1]-D2(b0))/(2*D2(p))+out[3]/(2*D2(q))
Y=Bcoord-D2(h)*A*A
ell=Q('1.634e-6');r=Q('4e-5');eps=Q('3.5e-13');L=Q('2e-8');aa=Q('24.6405');bb=Q('.000514');m=Q('.556');j=Q('1.47')
assert Q(A.v[1].b,M)<-aa and mag(A.v[2])<bb and mag(Y.v[3])<m and mag(Y.v[4])<j
# Point enclosures: recompute all three local gates from CP69G authenticated
# independent 268-step records; no CP69D point event arithmetic reused.
G=P/'CP69G';audit=read(G/'CP69G_FINAL_AUDIT.json');nodes=[]
def Hpoint(z):
    a,b,P1,P2=z;co=sharp(a-b,'cos');den=2-co*co
    return (P1*P1-2*co*P1*P2+2*P2*P2)/(2*den)-2*sharp(a,'cos')-sharp(b,'cos')
for label,u in [('m00',-ell),('center',Q(0)),('p04',ell)]:
    fname=G/f'CP69G_LOCAL_{label}_268_STEPS.json';dat=fname.read_bytes()
    sha=next(t['sha256'] for t in audit['local_events'] if t['label']==label);assert hashlib.sha256(dat).hexdigest()==sha
    d=json.loads(dat);assert Q(d['u'])==u and d['local_label']==label
    rr=d['records'];assert len(rr)==268 and all(Q(z['h'])==Q('.01') for z in rr[:-1]) and Q(rr[-1]['h'])==Q(d['T'])-Q('2.67')
    assert all(rr[k]['output_x']==rr[k+1]['input_x'] for k in range(267))
    ui=C(u);q2=C(b0)+p*(ui+h*ui*ui);p2=q*(ui-h*ui*ui)
    z=[R.load(t) for t in rr[0]['input_x']];assert z[1].contains(q2) and z[3].contains(p2) and z[2].contains(C(0))
    assert Rq(Q('.347'),Q('.351')).interior(z[0]);assert (-field_with_jac(z)[0][2]).a>Q('.5')*M
    assert (Hpoint([R(z[0].a,z[0].a),z[1],C(0),z[3]])+Q('.9')).b<0<(Hpoint([R(z[0].b,z[0].b),z[1],C(0),z[3]])+Q('.9')).a
    z=[R.load(t) for t in rr[-1]['output_x']];B=[t+Rq(Q('-1e-5'),Q('1e-5')) for t in z];f=field_with_jac(B)[0]
    dv=-z[2]/f[2];assert f[2].a>Q('.67')*M and mag(dv)<Q('1e-7')
    TT=R(min(0,dv.a),max(0,dv.b));assert all(t.interior(w+TT*d) for t,w,d in zip(B,z,f))
    assert (z[2]+R(dv.a,dv.a)*f[2]).b<=0<=(z[2]+R(dv.b,dv.b)*f[2]).a
    t=Q(d['T']);a,b=qbounds(dv);assert Q('2.67159995')<=t+a<=t+b<=Q('2.67172693')
    qe=z[1]+dv*f[1];pe=z[3]+dv*f[3];Xpt=(2*pi_bound()-qe-b0)/(2*p)-pe/(2*q);Ypt=(2*pi_bound()-qe-b0)/(2*p)+pe/(2*q)-h*Xpt*Xpt
    nodes.append((u,qbounds(Xpt),qbounds(Ypt)))
# Piecewise interpolation Y(u,0) and derivative. |f''| <= m.
H=Q(0);Du=Q(0)
for (u,x,y),(v,xx,yy) in zip(nodes,nodes[1:]):
 step=v-u;H=max(H,max(abs(t) for t in y+yy)+m*step*step/8)
 Du=max(Du,max(abs(yy[1]-y[0]),abs(yy[0]-y[1]))/step+m*step/2)
Duv=Du+j*eps;c=(1+bb*Duv)/aa
# det DF=1 -> |Y_v|<=c; graph inverse and transform.
height=H+c*eps;mu=aa-bb*L;kappa=1/mu;slope=(Duv+c*L)/mu
ct=c+(Duv+c*L)*bb/mu
coverL=nodes[0][1][0]-bb*eps;coverR=nodes[-1][1][1]+bb*eps
assert height<eps and slope<L and ct<1 and kappa<1 and coverL>r and coverR<-r
assert (aa+1)*(1-c)>bb*Duv and -aa+c<-2
# Bound fixed point u from X(u,g(u))=u; use center X(0,0).
uc=(max(abs(t) for t in nodes[1][1])+bb*height)/(aa+1)
vc=height;ru=vc+abs(h)*uc**2;rv=uc+abs(h)*ru**2
assert ru<ell and rv<eps
# Verify target chart on full graph output: when X∈[-r,r], |Y|<=height, q1 target in (.347,.351).
# Re-evaluate energy root globally over [-r,r] × [-eps,eps] via independent core.
U=Rq(-r,r);W=Rq(-eps,eps);q2=C(b0)+p*(U+W+h*U*U);p2=q*(U-W-h*U*U)
def energy(z):
 a,b,P1,P2=z;cc=trig_interval((a-b).a,(a-b).b,'cos');den=2-cc*cc
 return (P1*P1-2*cc*P1*P2+2*P2*P2)/(2*den)-2*trig_interval(a.a,a.b,'cos')-trig_interval(b.a,b.b,'cos')
lo=energy([C(Q('.347')),q2,C(0),p2])+Q('.9');hi=energy([C(Q('.351')),q2,C(0),p2])+Q('.9')
assert lo.b<0<hi.a
ff,_=field_with_jac([Rq(Q('.347'),Q('.351')),q2,C(0),p2]);der=-ff[2];assert der.a>Q('.68')*M
# Bound all possible source u of 35D root, and new smaller graph contraction constant.
first=read(P/'HOMOCLINIC_CP69C_2026-11-18'/'fresh_35d_rederived_E01'/'inputs'/'cp38_node0_proxy_anchor.json')
u0=Q(first['constructing_u']); assert u0-Q('1e-7')>uc and u0+Q('1e-7')<r
result={'source_sha256':expected,'target_q1':pair(targetq1),'target_chart_deriv':pair(der),'chart_left_H_plus_.9':pair(lo),'chart_right_H_plus_.9':pair(hi),'event_time_nodes_match':True,'Xu_upper':str(Q(A.v[1].b,M)),'Xv_abs_upper':str(mag(A.v[2])),'Yuu_abs_upper':str(mag(Y.v[3])),'Yuv_abs_upper':str(mag(Y.v[4])),'Y_u_bound':str(Duv),'Y_v_bound':str(c),'graph_height':str(height),'graph_slope':str(slope),'graph_transform_lip':str(ct),'inverse_base_lip':str(kappa),'coverage_left':str(coverL),'coverage_right':str(coverR),'fixed_u_bound':str(uc),'fixed_reflection_u_bound':str(ru),'fixed_reflection_v_bound':str(rv),'u_source_separation':str(u0-Q('1e-7')-uc)}
(P/'CP69Q_GRAPH_RESULT.json').write_text(json.dumps(result,indent=2));print('PASS graph', {k:float(Q(v)) for k,v in result.items() if isinstance(v,str) and k!='source_sha256'},'q1',list(map(float,qbounds(targetq1))))
