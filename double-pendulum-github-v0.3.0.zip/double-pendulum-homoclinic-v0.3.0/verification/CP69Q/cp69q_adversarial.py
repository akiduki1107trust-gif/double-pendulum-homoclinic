"""Reject incorrectly encoded or unsupported local jets. Includes two exact counterexamples."""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as Q
import json,gzip,sys
from cp69q_c2 import decode_records,step,dyad,exact_contains
from cp69q_new_kernel import C,R,M,sc,D2
if not __debug__:raise RuntimeError('no -O')
p=Path(__file__).resolve().parent/'CP69G/c2_traces/cp58_trace_part_000_020.json.gz'
d=json.loads(gzip.decompress(p.read_bytes()));X,Cen=map(decode_records,(d['first']['X'],d['first']['C']));rec=d['records'][0];zero=[0,0,0,0];reject=[]
step(X,Cen,rec)
for kind in ['false_Xnext','false_Cnext','zero_tube','invalid_sign']:
 b=deepcopy(rec)
 if kind=='false_Xnext':b['Xnext'][0][0]=[zero,zero]
 elif kind=='false_Cnext':b['Cnext'][0][0]=[zero,zero]
 elif kind=='zero_tube':b['ri'][0]=['0','0']
 else:b['Xnext'][0][0][0][0]=2
 try:step(X,Cen,b)
 except (AssertionError,ValueError,ZeroDivisionError):reject.append(kind)
 else:raise AssertionError(('accepted mutation',kind))
# Omitted factor 2 in normalized second derivatives: jet of u^2 has unit U^2 coefficient and raw second derivative 2.
u=D2([0,1,0,0,0,0]);assert (u*u).c[3].a==M and (u*u).v[3].a==2*M
# Outward-rounded output [0,1/M] contains 0, raw interval {2^-200} does not.
# 2^-200<1/M. Checking rounded inclusion alone cannot imply raw inclusion.
x=[0,1,-200,1];assert dyad(x)<Q(1,M);assert C(dyad(x)).contains(C(0));assert not exact_contains([x,x],C(0))
# sin on [1,2] has an interior maximum; sharp must include 1, while endpoint bounds exclude it.
a,b=C(1),C(2);assert sc(a.a,b.b)[0].b==M and sc(a.a,a.b)[0].b<M and sc(b.a,b.b)[0].b<M
out={'rejections':reject,'exact_counterexamples':3,'status':'PASS'}
print(json.dumps(out));(Path(__file__).resolve().parent/'CP69Q_ADVERSARIAL_RESULT.json').write_text(json.dumps(out,indent=2))
