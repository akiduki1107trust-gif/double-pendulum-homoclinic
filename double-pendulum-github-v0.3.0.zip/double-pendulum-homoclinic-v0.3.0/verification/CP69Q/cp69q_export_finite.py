"""Export 35+35 contraction inequalities as standalone Lean natural arithmetic goals.
The data conversion is verified by Python Fraction. Lean is not executed here.
"""
from fractions import Fraction as Q
from pathlib import Path
import json
if not __debug__:raise RuntimeError('no -O')
# Executes all final Fraction checks; no new candidate generation.
import cp69q_final as f
K=10**30
ceil=lambda q:-((-q*K)//1)
B=[[int(ceil(q)) for q in row] for row in f.B]
A=[int(ceil(q)) for q in f.a];L=[int(ceil(q)) for q in f.res]
def fixed(q):
 x=q*K;assert x.denominator==1 and x>0;return x.numerator
H=list(map(fixed,f.h));V=list(map(fixed,f.v))
assert all(B[i][j]>=0 and Q(B[i][j],K)>=f.B[i][j] for i in range(35) for j in range(35))
assert all(Q(A[i],K)>=f.a[i] and Q(L[i],K)>=f.res[i] for i in range(35))
assert max(map(sum,B))*1000<529*K
nl=[K*H[i]-(K*A[i]+sum(B[i][j]*H[j] for j in range(35))) for i in range(35)]
lm=[K*V[i]-(K*L[i]+sum(B[i][j]*V[j] for j in range(35))) for i in range(35)]
assert min(nl)>0 and min(lm)>0
s=['import Mathlib','', '-- Generated from checked rational majorants; NOT compiled here.', '-- Only the 70 finite integer inequalities and 35 row bounds, not ODE soundness.', 'set_option maxRecDepth 100000','set_option maxHeartbeats 0','namespace CP69Q','']
for prefix,bb,rr in [('nonlinear',A,H),('linear',L,V)]:
 for i in range(35):
  terms=[f'({bb[i]} : Nat) * {K}']+[f'{B[i][j]} * {rr[j]}' for j in range(35) if B[i][j]]
  s += [f'theorem {prefix}_{i:02d} :','  '+' +\n  '.join(terms)+f' < {K*rr[i]} := by','  decide','']
for i in range(35):
 terms=[f'({B[i][0]} : Nat)']+[str(x) for x in B[i][1:]]
 s += [f'theorem row_bound_{i:02d} :','  1000 * ('+' + '.join(terms)+f') < {529*K} := by','  decide','']
s+=['end CP69Q','']
p=Path(__file__).resolve().parent
(p/'CP69Q_FiniteContraction.lean').write_text('\n'.join(s))
result={'scale':str(K),'B':[[str(q) for q in r] for r in B],'a':list(map(str,A)),'linear_residual':list(map(str,L)),'nonlinear_radii':list(map(str,H)),'linear_radii':list(map(str,V)),'nonlinear_min_margin':str(Q(min(nl),K*K)),'linear_min_margin':str(Q(min(lm),K*K)),'row_max':str(Q(max(map(sum,B)),K)),'integer_checks':105,'lean_compiled':False}
(p/'CP69Q_FINITE_CONTRACTION.json').write_text(json.dumps(result,indent=2));print('PASS integer scale 105 conditions',float(Q(min(nl),K*K)),float(Q(min(lm),K*K)))
