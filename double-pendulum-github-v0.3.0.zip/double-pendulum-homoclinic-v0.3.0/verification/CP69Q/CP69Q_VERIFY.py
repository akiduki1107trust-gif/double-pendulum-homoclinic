#!/usr/bin/env python3
"""Recreate all inputs from immutable CP69P and check new results."""
import hashlib,json,sys,zipfile,tempfile,shutil,subprocess,concurrent.futures
from pathlib import Path
if not __debug__:raise RuntimeError('no -O')
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in json.loads((P/'SHA256.json').read_text()).items():assert sha(P/n)==h,n
parent=next(P.glob('HOMOCLINIC_CP69P_*.zip'))
assert sha(parent)=='32d3694d04310de30e26ef5dd156787765443dca0458580d0418133170abf41a'
with tempfile.TemporaryDirectory(prefix='cp69q-') as td:
 t=Path(td)
 def extract(z):
  with zipfile.ZipFile(z) as a:assert a.testzip() is None;a.extractall(t)
 extract(parent)
 for n,h in json.loads((t/'CP69P/SHA256.json').read_text()).items():assert sha(t/'CP69P'/n)==h,n
 for pat in ('HOMOCLINIC_CP69O_*.zip','HOMOCLINIC_CP69H_*.zip'):extract(next((t/'CP69P').glob(pat)))
 extract(next((t/'CP69H').glob('UPSTREAM_HOMOCLINIC_CP69G_*.zip')))
 with zipfile.ZipFile(next((t/'CP69O').glob('UPSTREAM_CP69N*.zip'))) as z:
  m=t/'M.zip';m.write_bytes(z.read('CP69N/UPSTREAM_CP69M_2026-11-19.zip'))
 extract(m)
 with zipfile.ZipFile(next((t/'CP69O').glob('UPSTREAM_CP69D*.zip'))) as z:
  for n in z.namelist():
   if n.endswith(('cp38_node0_proxy_anchor.json','cp34_node_anchors.json','CP69D_integer_energy_lift_result.json')):z.extract(n,t)
 for f in P.glob('cp69q_*.py'):shutil.copy2(f,t/f.name)
 def run(a):
  r=subprocess.run([sys.executable,*map(str,a)],cwd=t,check=True,capture_output=True,text=True)
  print('PASS',a[0], ' '.join(map(str,a[1:])),flush=True);return r.stdout
 run(['cp69q_anchor.py','--parts','8','--qrad','6e-8'])
 if '--all' in sys.argv:
  jobs=[['cp69q_c2.py',i] for i in range(14)]+[['cp69q_c0.py',t/f'CP69G/CP69G_LOCAL_{s}_268_STEPS.json'] for s in ['center','m00','p04']]
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(run,jobs))
 else:run(['cp69q_c2.py',13])
 for f,names in [('cp69q_graph.py',['CP69Q_GRAPH_RESULT.json']),('cp69q_lift.py',['CP69Q_LIFT_RESULT.json']),('cp69q_multishoot.py',['CP69Q_MULTISHOOT_RESULT.json','CP69Q_NEW_PHYSICAL35D.json','CP69Q_35D_HULL.json']),('cp69q_final.py',['CP69Q_FRACTION_FINAL_RESULT.json']),('cp69q_export_finite.py',['CP69Q_FINITE_CONTRACTION.json','CP69Q_FiniteContraction.lean']),('cp69q_adversarial.py',['CP69Q_ADVERSARIAL_RESULT.json'])]:
  run([f]);assert all((t/n).read_bytes()==(P/n).read_bytes() for n in names),names
 for f in ['cp69q_c2.py','cp69q_c0.py','cp69q_anchor.py','cp69q_graph.py','cp69q_multishoot.py','cp69q_final.py','cp69q_export_finite.py','cp69q_adversarial.py']:
  assert subprocess.run([sys.executable,'-O',f],cwd=t,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
 if '--parent-full' in sys.argv:run([t/'CP69P/CP69P_VERIFY.py','--full'])
print('CP69Q verified; Lean not run; '+('all new local steps' if '--all' in sys.argv else 'quick (last 7 C2 steps)'))
