#!/usr/bin/env python3
"""CP69-Q second scalar/jet kernel replay of local C2 certificates.
New scalar interval and parameter jet modules; time recurrence and witness code retained from CP69-G.
Not Lean formal verification; source implementation soundness remains OPEN.
"""
import json,gzip,sys,hashlib
from pathlib import Path
from fractions import Fraction as Q
from cp69q_new_kernel import R,C,ZERO,ONE,M,sharp,D2
if not __debug__:raise RuntimeError('Python -O not permitted')
DATA=Path(__file__).resolve().parent/'CP69G'/'c2_traces'
U=C(Q('0.000001634')); U=R(-U.b,U.b)
V=C(Q('3.5e-13')); V=R(-V.b,V.b)
H=Q('0.01')
RAD=[Q(2),Q(2),Q(2000),Q(20),Q(2000)]

DZ=D2(0)

def mult(a,b,n):return [sum((a[j]*b[k-j] for j in range(k+1)),DZ) for k in range(n+1)]
def invert(a,n):
    w=[a[0].inv()]
    for k in range(1,n+1):w.append(-w[0]*sum((a[j]*w[k-j] for j in range(1,k+1)),DZ))
    return w

def sseries(a,n):
    s,c=a[0].sincos();ss=[s];cc=[c]
    for k in range(1,n+1):
        ss.append(sum((j*a[j]*cc[k-j] for j in range(1,k+1)),DZ)/k)
        cc.append(-sum((j*a[j]*ss[k-j] for j in range(1,k+1)),DZ)/k)
    return ss,cc

def field_series(y,n):
    q1,q2,p1,p2=[a[:n+1] for a in y]
    delta=[a-b for a,b in zip(q1,q2)]
    ds,dc=sseries(delta,n)
    c2=mult(dc,dc,n)
    den=[D2(2)-c2[0]]+[-t for t in c2[1:]]
    invd=invert(den,n)
    u1=mult([a-b for a,b in zip(p1,mult(dc,p2,n))],invd,n)
    u2=mult([2*a-b for a,b in zip(p2,mult(dc,p1,n))],invd,n)
    z=mult(ds,mult(u1,u2,n),n)
    s1,_=sseries(q1,n);s2,_=sseries(q2,n)
    return [u1,u2,[-z[j]-2*s1[j] for j in range(n+1)],[z[j]-s2[j] for j in range(n+1)]]

def jets(x,n):
    z=[[v] for v in x]
    for k in range(n):
        f=field_series(z,k)
        for i in range(4):z[i].append(f[i][k]/(k+1))
    return z

def dyad(z):
    sg,m,e,bits=z
    assert type(sg)==int and sg in (0,1) and type(m)==int and m>=0 and type(e)==int and type(bits)==int and m.bit_length()==bits
    w=Q(m)*(Q(2)**e)
    return -w if sg else w

def exact_contains(raw, x):
    lo,hi=map(dyad,raw)
    return lo<=Q(x.a,M)<=Q(x.b,M)<=hi

def raw_interval(z):
    a,b=z;aa=dyad(a);bb=dyad(b)
    lo=R.q(aa);hi=R.q(bb)
    assert aa<=bb
    return R(lo.a,hi.b)

def decoded_jet(y):return D2([raw_interval(pair) for pair in y])
def decode_records(y):
    assert len(y)==4 and all(len(v)==6 for v in y)
    return [decoded_jet(v) for v in y]

def step(x,c,rec):
    Xn=decode_records(rec['Xnext']);Cn=decode_records(rec['Cnext'])
    accepted=[]
    for inp in [x,c]:
        tube=[]
        for i in range(4):
            z0=rec['ri'][i]
            # ri is two exact decimal strings in data, not dyadic intervals.
            r0=R(R.q(Q(z0[0])).a,R.q(Q(z0[1])).b)
            coeff=[r0]+[inp[i].v[j+1]+R(-R.q(RAD[j]).b,R.q(RAD[j]).b) for j in range(5)]
            t=D2(coeff);tube.append(t)
            for k in range(6):assert t.v[k].interior(inp[i].v[k]),('initial tube',rec['k'],i,k)
        f=field_series([[v] for v in tube],0)
        for i in range(4):
            for k in range(6):
                bound=inp[i].v[k]+R(0,R.q(H).b)*f[i][0].v[k]
                assert tube[i].v[k].interior(bound),('Picard C2',rec['k'],i,k)
        A=jets(inp,6);B=jets(tube,7)
        powers=[R.q(H**k) for k in range(8)]
        accepted.append([sum((A[i][j]*powers[j] for j in range(7)),DZ)+B[i][7]*powers[7] for i in range(4)])
    XT,CT=accepted
    for i in range(4):
        for k in range(6):assert exact_contains(rec['Cnext'][i][k],CT[i].v[k]),('exact dyadic center Taylor',rec['k'],i,k)
        z=XT[i].v
        M0=Cn[i].v[0]+z[1]*U+z[2]*V
        M1=Cn[i].v[1]+z[3]*U+z[4]*V
        M2=Cn[i].v[2]+z[4]*U+z[5]*V
        for k in range(6):
            if k<3:
                lo=max(z[k].a,[M0,M1,M2][k].a)
                hi=min(z[k].b,[M0,M1,M2][k].b)
                assert lo<=hi,('empty jet intersection',rec['k'],i,k)
                actual=R(lo,hi)
            else:actual=z[k]
            assert exact_contains(rec['Xnext'][i][k],actual),('exact dyadic strip Taylor',rec['k'],i,k)
    return Xn,Cn

def filecheck(f):
    raw=f.read_bytes();d=json.loads(gzip.decompress(raw));assert d['records']
    x=decode_records(d['first']['X']);c=decode_records(d['first']['C'])
    for k,rec in enumerate(d['records'],d['lo']):
        assert rec['k']==k
        x,c=step(x,c,rec)
    assert d['records'][-1]['k']+1==d['end_step']
    assert d['end_step']==d['lo']+len(d['records'])
    assert d['last']['X']==d['records'][-1]['Xnext']
    assert d['last']['C']==d['records'][-1]['Cnext']
    o={'file':f.name,'n':len(d['records']),'first_k':d['records'][0]['k'],'last_k':d['records'][-1]['k'],
       'sha256':hashlib.sha256(raw).hexdigest(),'status':'PASS'}
    print('PASS C2 piece',f.name,len(d['records']),flush=True)
    return o

def main(parts=None):
    files=sorted(DATA.glob('cp58_trace_part_*.json.gz'))
    assert len(files)==14
    meta=[]
    prev=None
    for i,p in enumerate(files):
        d=json.loads(gzip.decompress(p.read_bytes()))
        assert d['lo']==d['records'][0]['k'] and d['lo']==(0 if prev is None else prev['end_step'])
        if prev is not None:
            assert prev['last']==d['first'],('C2 part chain break',i)
        prev=d
        if parts is None or i in parts:meta.append(filecheck(p))
    n=sum(x['n'] for x in meta)
    assert prev['end_step']==267 and sum(len(json.loads(gzip.decompress(p.read_bytes()))['records']) for p in files)==267
    z={'status':'PASS','pieces_verified':len(meta),'steps_verified':n,'picard_conditions':48*n,
     'taylor_endpoint_conditions':48*n,'pieces':meta,
     'qualification':'CP69Q new scalar and normalized parameter-jet kernel; CP69G time recurrence and witness control reused. Lean OPEN.'}
    out=Path(__file__).resolve().parent/('CP69Q_C2_CHECK_RESULT.json' if parts is None else 'CP69Q_C2_PART_'+ '_'.join(str(x) for x in sorted(parts))+'.json')
    out.write_text(json.dumps(z,indent=2))
    print(json.dumps({'status':'PASS','steps_verified':n,'pieces':len(meta)}))
    return z
if __name__=='__main__':main(set(int(t) for t in sys.argv[1].split(',')) if len(sys.argv)>1 else None)
