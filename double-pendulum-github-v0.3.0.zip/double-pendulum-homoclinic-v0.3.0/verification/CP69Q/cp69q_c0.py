#!/usr/bin/env python3
"""CP69-G independent 4D C0 Taylor/Picard certificate checker.
Uses CP69-Q 55-digit no-reduction interval/trig kernel; CP69-G time recurrence retained.
No imports from untrusted CP69-D producer. It accepts claimed step data only
if recomputed Picard and Taylor inclusions are strict/valid.
NOT a formal Lean proof of Python semantics.
"""
import json,sys
if not __debug__:raise RuntimeError('assertions must be enabled')
from fractions import Fraction as Q
from cp69q_new_kernel import R, C, ZERO, ONE, M, sharp
def trig_interval(a,b,kind):return sharp(R(a,b),kind)
def load45(v):
    assert len(v)==2
    return R(int(v[0])*10**10,int(v[1])*10**10)

def plus(a,b,n):return [a[k]+b[k] for k in range(n+1)]
def sub(a,b,n):return [a[k]-b[k] for k in range(n+1)]
def mul(a,b,n):return [sum((a[j]*b[k-j] for j in range(k+1)),ZERO) for k in range(n+1)]
def inv(a,n):
    w=[a[0].inv()]
    for k in range(1,n+1):w.append(-w[0]*sum((a[j]*w[k-j] for j in range(1,k+1)),ZERO))
    return w

def sincos(a,n):
    s=[trig_interval(a[0].a,a[0].b,'sin')];c=[trig_interval(a[0].a,a[0].b,'cos')]
    for k in range(1,n+1):
        s.append(sum((j*a[j]*c[k-j] for j in range(1,k+1)),ZERO)/k)
        c.append(-sum((j*a[j]*s[k-j] for j in range(1,k+1)),ZERO)/k)
    return s,c

def fpoly(y,n):
    a,b,p,q=[v[:n+1] for v in y]
    ds,dc=sincos(sub(a,b,n),n)
    asn,_=sincos(a,n);bsn,_=sincos(b,n)
    den=sub([C(2)]+[ZERO]*n,mul(dc,dc,n),n)
    di=inv(den,n)
    u1=mul(sub(p,mul(dc,q,n),n),di,n)
    u2=mul(sub([2*x for x in q],mul(dc,p,n),n),di,n)
    cross=mul(ds,mul(u1,u2,n),n)
    return [u1,u2,sub([-x for x in cross],[2*x for x in asn],n),sub(cross,bsn,n)]

def jets(X,n):
    Y=[[x] for x in X]
    for k in range(n):
        d=fpoly(Y,k)
        for i in range(4):Y[i].append(d[i][k]/(k+1))
    return Y

def chk(rec):
    assert rec['version']=='CP69G-4D-C0-STEP-v1'
    n=rec['order'];assert n in [7,8,10,12]
    h=Q(rec['h']);assert 0<h<Q(1,20)
    X=[load45(v) for v in rec['input_x']]
    B=[load45(v) for v in rec['picard_B']]
    Y=[load45(v) for v in rec['output_x']]
    assert len(X)==len(B)==len(Y)==4
    f=[v[0] for v in fpoly([[x] for x in B],0)]
    hrange=R(0,R.q(h).b)
    for i in range(4):
        assert B[i].interior(X[i]),('initial',i)
        assert B[i].interior(X[i]+hrange*f[i]),('picard',i)
    coeff=jets(X,n);rem=jets(B,n+1)
    powers=[R.q(h**k) for k in range(n+2)]
    for i in range(4):
        calc=sum((coeff[i][k]*powers[k] for k in range(n+1)),ZERO)+rem[i][n+1]*powers[n+1]
        assert Y[i].contains(calc),('Taylor',i)
    return {'state_picard_tests':4,'state_endpoint_tests':4,'degree':n,'node':rec['node'],'step':rec['step_index']}

def chain(path,start=0,end=None):
    import hashlib
    raw=open(path,'rb').read();data=json.loads(raw)
    assert data['version']=='CP69G-4D-C0-CHAIN-v1'
    records=data['records'];assert len(records)>0
    end=len(records) if end is None else end
    assert 0<=start<end<=len(records)
    for i,r in enumerate(records):
        assert r['step_index']==i
        if i:
            assert records[i-1]['node']==r['node']
            assert records[i-1]['output_x']==r['input_x'],('chain',i)
    for i in range(start,end):
        chk(records[i]);
        if (i+1)%20==0 or i+1==end:print('verified C0',records[i]['node'],i+1,'/',len(records),flush=True)
    result={'PASS':True,'node':records[0]['node'],'steps_validated':end-start,
       'range':[start,end],'chain_length':len(records),'conditions':8*(end-start),'sha256':hashlib.sha256(raw).hexdigest()}
    print(json.dumps(result))
    return result
if __name__=='__main__':chain(sys.argv[1],int(sys.argv[2]) if len(sys.argv)>2 else 0,int(sys.argv[3]) if len(sys.argv)>3 else None)
