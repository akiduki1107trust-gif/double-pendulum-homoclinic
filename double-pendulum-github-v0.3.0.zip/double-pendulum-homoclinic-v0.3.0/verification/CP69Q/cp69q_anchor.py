#!/usr/bin/env python3
"""Independently bound CP58/CP69G full-strip initial 2-parameter C2 jet.
Uses CP69Q's new 55-digit grid and non-reduced trigonometric kernel;
never imports CP69G's D2 or its C2 trace checker or CP69D implicit jets.
An external Python, non-formal computation. 3-variable Hessian differentiation.
"""
import sys, json, gzip, hashlib
if not __debug__:raise RuntimeError("no -O")
from pathlib import Path
from fractions import Fraction as Q
sys.path.insert(0,str(Path(__file__).resolve().parent/'CP69G'))
from cp69q_new_kernel import R,C,ZERO,ONE,M,sharp
def trig_interval(a,b,kind):return sharp(R(a,b),kind)

N=3
class T:
    __slots__=('x','g','h')
    def __init__(self,x,g=None,h=None):
        self.x=C(x);self.g=[ZERO]*3 if g is None else list(g)
        self.h=[[ZERO]*3 for _ in range(3)] if h is None else h
    def __add__(self,o):
        o=to(o);return T(self.x+o.x,[a+b for a,b in zip(self.g,o.g)],[[self.h[i][j]+o.h[i][j] for j in range(3)] for i in range(3)])
    __radd__=__add__
    def __neg__(self):return T(-self.x,[-x for x in self.g],[[-x for x in row] for row in self.h])
    def __sub__(self,o):return self+-to(o)
    def __rsub__(self,o):return to(o)+-self
    def __mul__(self,o):
        o=to(o)
        return T(self.x*o.x,[self.g[i]*o.x+self.x*o.g[i] for i in range(3)],
            [[self.h[i][j]*o.x+self.g[i]*o.g[j]+self.g[j]*o.g[i]+self.x*o.h[i][j] for j in range(3)] for i in range(3)])
    __rmul__=__mul__
    def fun(self,f,fp,fpp):
        return T(f,[fp*self.g[i] for i in range(3)],
             [[fpp*self.g[i]*self.g[j]+fp*self.h[i][j] for j in range(3)] for i in range(3)])
    def inv(self):
        r=self.x.inv();return self.fun(r,-r*r,2*r*r*r)
    def __truediv__(self,o):return self*to(o).inv()
    def __rtruediv__(self,o):return to(o)*self.inv()
    def sin(self):
        s=trig_interval(self.x.a,self.x.b,'sin');c=trig_interval(self.x.a,self.x.b,'cos')
        return self.fun(s,c,-s)
    def cos(self):
        s=trig_interval(self.x.a,self.x.b,'sin');c=trig_interval(self.x.a,self.x.b,'cos')
        return self.fun(c,-s,-c)

def to(x):return x if isinstance(x,T) else T(x)
def variable(x,i):
    z=T(x);z.g[i]=ONE;return z

def field(Q1,U,V):
    p=to(Q('0.8242999233'));q=to(Q('0.5661533683'))
    hh=to(Q('-0.0026488571962644'));b=to(Q('3.3447126987001807'))
    q2=b+p*(U+V+hh*U*U)
    p2=q*(U-V-hh*U*U)
    c=(Q1-q2).cos(); den=2-c*c
    return p2*p2/den-2*Q1.cos()-q2.cos()+C(Q('0.9'))

def Fonly(q,u,v):return field(T(q),T(u),T(v)).x

QZERO=Q(0);Umax=Q('0.000001634');Vmax=Q('3.5e-13')
Vbox=R.q(-Vmax)+R.q(Q(0))
Vbox=R(-C(Vmax).b,C(Vmax).b)
q0=Q('0.34898293693882115');slope=Q('0.24314472735009482')
trace=Path(__file__).resolve().parent/'CP69G/c2_traces/cp58_trace_part_000_020.json.gz'
record=json.loads(gzip.decompress(trace.read_bytes()))['first']

def Dyad(z):
    sign,m,e,bits=z;m=int(m);e=int(e)
    assert m.bit_length()==int(bits)
    x=Q(m)*Q(2)**e
    return -x if sign else x

def exact_contains(raw,x):
    a,b=map(Dyad,raw)
    return a<=Q(x.a,M)<=Q(x.b,M)<=b

def original_interval(v):
    a,b=map(Dyad,v)
    return R(C(a).a,C(b).b)

bound=[[original_interval(pair) for pair in item] for item in record['X']]
center=[[original_interval(pair) for pair in item] for item in record['C']]

def join(l,r):return R(min(l.a,r.a),max(l.b,r.b))

def jet_from_t(t):
    # q1 implicit: F(q1(u,v),u,v)=0. Derivatives from Hessian in (Q,u,v).
    g=t.g;h=t.h
    inv=t.g[0].inv()
    u=-g[1]*inv;v=-g[2]*inv
    uu=-(h[1][1]+2*h[0][1]*u+h[0][0]*u*u)*inv
    uv=-(h[1][2]+h[0][1]*v+h[0][2]*u+h[0][0]*u*v)*inv
    vv=-(h[2][2]+2*h[0][2]*v+h[0][0]*v*v)*inv
    return [u,v,uu,uv,vv]

def convex_qbox(u1,u2,qrad):
    u0=(u1+u2)/2
    qc=q0+slope*u0
    return R(C(qc-qrad).a,C(qc+qrad).b)

def audit(nparts=32,rad=Q('0.00000006')):
    incls=[None]*6
    smallest_margin=None
    mdiv=0
    prev_qbox=None
    for j in range(nparts):
        lo=-Umax+(2*Umax*j)/nparts
        hi=-Umax+(2*Umax*(j+1))/nparts
        U=R(C(lo).a,C(hi).b)
        qb=convex_qbox(lo,hi,rad)
        if prev_qbox is not None:
            assert qb.a<=prev_qbox.b and prev_qbox.a<=qb.b,('root branch boxes disjoint',j)
        prev_qbox=qb
        # Quantified in (u,v). Check lower & upper root signs and F_Q positive.
        lower=Fonly(R(qb.a,qb.a),U,Vbox)
        upper=Fonly(R(qb.b,qb.b),U,Vbox)
        if not (lower.b<0<upper.a):
            print('SIGN FAIL',nparts,j,float(Q(lower.b,M)),float(Q(upper.a,M)),flush=True)
            return False
        t=field(variable(qb,0), variable(U,1),variable(Vbox,2))
        if t.g[0].a<=0:raise Exception(('F_Q not pos',j,t.g[0]))
        mdiv=t.g[0].a if j==0 else min(mdiv,t.g[0].a)
        z=jet_from_t(t)
        jet=[qb]+z
        for k in range(6):
            incls[k]=jet[k] if incls[k] is None else join(incls[k],jet[k])
        # each derived q1 jet and q2/p2 jet must fit saved 24-component X per tile.
        for k in range(6):
            if not exact_contains(record['X'][0][k],jet[k]):
                print('SUBSET FAIL',nparts,j,k,'new',list(map(float,[Q(jet[k].a,M),Q(jet[k].b,M)])),'saved',list(map(float,[Q(bound[0][k].a,M),Q(bound[0][k].b,M)])),flush=True)
                return False
        if j%max(1,nparts//8)==0:print('part',j,'/',nparts,flush=True)
    print('min F_Q',float(Q(mdiv,M)))
    for k,z in enumerate(incls):
        print('overall',k,'new',float(Q(z.a,M)),float(Q(z.b,M)),'original',float(Q(bound[0][k].a,M)),float(Q(bound[0][k].b,M)))
    return True


def audit_center():
    qq=center[0][0]
    for _ in range(14):
        m1=qq.a+(qq.b-qq.a)//4
        m3=qq.b-(qq.b-qq.a)//4
        if m1==qq.a or m3==qq.b:break
        ff1=Fonly(R(m1,m1),ZERO,ZERO)
        ff3=Fonly(R(m3,m3),ZERO,ZERO)
        if ff1.b<0 and ff3.a>0:qq=R(m1,m3)
        else:break
    print('center root subdivision width',float(Q(qq.b-qq.a,M)))
    lo=Fonly(R(qq.a,qq.a),ZERO,ZERO)
    hi=Fonly(R(qq.b,qq.b),ZERO,ZERO)
    print('center sign',float(Q(lo.b,M)),float(Q(hi.a,M)))
    assert lo.b<0<hi.a
    f=field(variable(qq,0),variable(ZERO,1),variable(ZERO,2))
    assert f.g[0].a>0
    z=[qq]+jet_from_t(f)
    for j in range(6):
        if not exact_contains(record['C'][0][j],z[j]):
            print('CENTER FAIL',j,'computed',float(Q(z[j].a,M)),float(Q(z[j].b,M)), 'diff',float(Q(z[j].a-center[0][j].a,M)))
            return False
    print('CENTER q1 6/6 PASS')
    return True

def q2p2_jets():
    p=Q('0.8242999233');q=Q('0.5661533683');h=Q('-0.0026488571962644');b=Q('3.3447126987001807')
    UM=Umax;VM=Vmax
    q2=lambda u,v:b+p*(u+v+h*u*u)
    p2=lambda u,v:q*(u-v-h*u*u)
    q2j=[(q2(-UM,-VM),q2(UM,VM)),(p*(1+2*h*UM),p*(1-2*h*UM)),(p,p),(2*p*h,2*p*h),(Q(0),Q(0)),(Q(0),Q(0))]
    p2j=[(p2(-UM,VM),p2(UM,-VM)),(q*(1+2*h*UM),q*(1-2*h*UM)),(-q,-q),(-2*q*h,-2*q*h),(Q(0),Q(0)),(Q(0),Q(0))]
    for idx,jets in [(1,q2j),(3,p2j)]:
        for k,(a,b) in enumerate(jets):
            zz=R(C(a).a,C(b).b)
            assert exact_contains(record['X'][idx][k],zz),('full 24D source enclosure failure',idx,k,zz,bound[idx][k])
            ctr=R.q((a+b)/2) if k>2 else None
            # For centered q2/p2, direct exact polynomial values (u=v=0).
            if idx==1:
                v=[Q('3.3447126987001807'),p,p,2*p*h,Q(0),Q(0)][k]
            else:
                v=[Q(0),q,-q,-2*q*h,Q(0),Q(0)][k]
            assert exact_contains(record['C'][idx][k],C(v)),('center polynomial not included',idx,k)
        print('state',idx,'full strip and center 6/6 PASS')
    for k in range(6):
        assert exact_contains(record['X'][2][k],ZERO)
        assert exact_contains(record['C'][2][k],ZERO)
    print('p1=0 6/6 PASS')
    return True

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--parts',type=int,default=32);ap.add_argument('--qrad',default='6e-8')
    args=ap.parse_args()
    print('START FULL',args.parts,args.qrad,flush=True)
    assert audit(args.parts,Q(args.qrad))
    assert audit_center()
    assert q2p2_jets()
    print('CP69H FULL STRIP+CENTER 24x2 INITIAL JET PASS',flush=True)
