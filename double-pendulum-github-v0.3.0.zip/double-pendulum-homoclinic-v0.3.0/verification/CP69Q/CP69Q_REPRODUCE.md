# CP69-Q 再現

- ZIPの親CP69-Pは無変更。`python CP69Q_VERIFY.py` は全ファイルSHA、親ZIP CRC、原資料の展開、48初期jet、最終7 C2ステップ、グラフ・持ち上げ・35D・105整数条件・反証試験を再生する。
- `python CP69Q_VERIFY.py --all`: 上記に加え、14分割の全267 C2 と3本の全804 local C0を再生。`--parent-full` も指定すれば親CP69Pの `--full` を実行する。
- 全267+804の新チェック、および親CP69P `--full` は今回個別に実行済み。`logs/` に終了ログを保存。新ラッパーそのものはquickを空ディレクトリで検査。
- `CP69Q_FiniteContraction.lean`: Mathlibを持つLean環境でのビルド用草稿。現在Lean/lakeがないため未コンパイル。105の有限算術命題のみ、ODE形式証明ではない。
- CP69Q_THEOREMS.md: 算術、三角関数、正規化jet、raw包含、35Dへの接続、条件付き解析的非可積分性の証明。前研究の数学・証明書は親ZIPを参照。
