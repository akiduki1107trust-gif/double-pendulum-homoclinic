#!/usr/bin/env python3
"""Independent exact Fraction checker for nonlinear box and terminal linear response.
No CP69F, NumPy, or candidate generator imported. Separate natural interval arithmetic.
"""
from fractions import Fraction as Q
from pathlib import Path
from math import factorial,isqrt
import json,hashlib
if not __debug__:raise RuntimeError('no -O')
P=Path(__file__).resolve().parent;read=lambda p:json.loads(p.read_text());raw=read(P/'CP69Q_NEW_PHYSICAL35D.json');M=10**45;N=35
assert raw['dimension']==N and raw['scale']==M
class I:
 def __init__(self,a,b=None):self.a=Q(a);self.b=Q(a if b is None else b);assert self.a<=self.b
 def __add__(s,t):t=iv(t);return I(s.a+t.a,s.b+t.b)
 __radd__=__add__
 def __neg__(s):return I(-s.b,-s.a)
 def __sub__(s,t):return s+-iv(t)
 def __rsub__(s,t):return iv(t)+-s
 def __mul__(s,t):
  t=iv(t);p=[s.a*t.a,s.a*t.b,s.b*t.a,s.b*t.b];return I(min(p),max(p))
 __rmul__=__mul__
 def __truediv__(s,t):t=iv(t);assert t.a*t.b>0;return s*I(1/t.b,1/t.a)
 def __rtruediv__(s,t):return iv(t)/s
 def abs(s):return max(abs(s.a),abs(s.b))
 def contains(s,t):t=iv(t);return s.a<=t.a<=t.b<=s.b
 def pair(s):return list(map(str,[s.a,s.b]))
def iv(t):return t if isinstance(t,I) else I(t)
def load(z):return I(Q(int(z[0]),M),Q(int(z[1]),M))
def pm(t):return I(-t,t)
def grid(x):return I(Q(x.a*M//1,M),Q(-((-x.b*M)//1),M))
def trig(x,par):
 m=(x.a+x.b)/2;w=(x.b-x.a)/2;assert abs(m)<9
 sm=sum(((-1)**k*m**(2*k+par)/factorial(2*k+par) for k in range(45)),Q(0));rem=abs(m)**(89+par)/factorial(89+par)
 other=1-par
 dsm=sum(((-1)**k*m**(2*k+other)/factorial(2*k+other) for k in range(45)),Q(0));derr=abs(m)**(89+other)/factorial(89+other)
 w=w*min(Q(1),abs(dsm)+derr+w)
 return grid(I(max(Q(-1),sm-rem-w),min(Q(1),sm+rem+w)))
def field(x):
 a,b,p,q=x;co=trig(a-b,0);si=trig(a-b,1);de=2-co*co;u=(p-co*q)/de;v=(2*q-co*p)/de;cross=si*u*v
 return [u,v,-cross-2*trig(a,1),cross-trig(b,1)]
C=[[load(t) for t in row] for row in raw['C']];assert all(t.a==t.b for row in C for t in row)
J=[[load(t) for t in row] for row in read(P/'CP69Q_35D_HULL.json')];assert len(J)==N
E=read(P/'CP69Q_MULTISHOOT_RESULT.json');E0=Q(E['E0']);E1=Q(E['E1']);coef=Q('8.486')
assert E['raw_sha256']==hashlib.sha256((P/'CP69Q_NEW_PHYSICAL35D.json').read_bytes()).hexdigest()
# Independent Fraction matrix product, with explicit small support for true-curve discrepancy.
for i in range(3):J[i][0]+=pm(coef*E1)
A=[[(int(i==j))-sum(C[i][k]*J[k][j] for k in range(N)) for j in range(N)] for i in range(N)]
B=[[v.abs() for v in row] for row in A];theta=max(map(sum,B));assert theta<Q('.54')
# residual correction confined to rows 0..2. The true initial flow point can be
# anywhere in the common C1 box; correction bound via segment mean value theorem.
r=[load(t) for t in raw['residual']]
for i in range(3):r[i]+=pm(coef*E0)
a=[sum(C[i][k]*r[k] for k in range(N)).abs() for i in range(N)]
old=read(P/'CP69M/CP69M_COMPONENTWISE_24D_CERTIFICATE.json');h0=list(map(Q,old['coordinate_radii']))
# conservative enlargement of candidate radius; never claim old margins under changed bounds.
h=[v+Q('1e-14') for v in h0];margin=[h[i]-a[i]-sum(B[i][j]*h[j] for j in range(N)) for i in range(N)]
assert all(0<v<Q('1e-7') for v in h) and min(margin)>0
# Since CJ nonsingular from theta<1, C and J are nonsingular (no separate modular dependency needed).
# Linear response: J z = e33. Frozen center and radii generated independently in previous script.
S=read(P/'CP69O/CP69O_SENSITIVITY_RESULT.json');x=list(map(Q,S['center']));v=list(map(Q,S['radius']));assert len(v)==len(x)==N and min(v)>0
res=[(C[i][33]+sum(A[i][j]*x[j] for j in range(N))-x[i]).abs() for i in range(N)]
lm=[v[i]-res[i]-sum(B[i][j]*v[j] for j in range(N)) for i in range(N)];assert min(lm)>0
Z=[I(t-s,t+s) for t,s in zip(x,v)];assert Z[0].a>Q('3.7e-5')
# Last output derivative independent of original field/trig implementation.
nodes=read(P/'HOMOCLINIC_CP69C_2026-11-18/fresh_35d_rederived_E01/inputs/cp34_node_anchors.json');last=nodes[-1];e=last['e'];assert e==0
s=[I(Q(t))+pm(Q('2.1e-7')) for t in last['center']];f=field(s);g=[-f[2],-f[3],f[0],f[1]];keep=[1,2,3];assert g[0].a>0
Dchi=[[iv(int(i==j)) if i!=e else -g[j]/g[e] for j in keep] for i in range(4)]
lastrec=read(P/'CP69M/CP69M_24D/cp69m_24d_11_124.json')['records'][-1];dt=Q('1e-7')/12+abs(Q('14.7446280595979')/12-124*Q('.00990902423360074'));fudge=100*dt*20/(1-100*dt)
end=[load(t)+pm(Q('1e-5')) for t in lastrec['output_x'][:4]];f=field(end);assert f[1].a>Q('.739')
W=[load(t)+pm(fudge) for t in lastrec['output_V'][2]]
m=f[2]/12*Z[1]+sum(sum(W[k]*Dchi[k][j] for k in range(4))*Z[32+j] for j in range(3))
assert m.a>Q('.3527') and m.b<Q('.6854'),(float(m.a),float(m.b))
slope=Q('.3527');sine=2*slope/(1+slope*slope);assert sine>Q('.62735');eps=Q('.332');assert eps**2<slope*slope/(1+slope*slope)
# Perturbation test: overlarge error can collapse the tangent lines exactly.
# v=(1,m), w=(1,-m); both perturbed to (1,0) with relative m/sqrt(1+m^2).
# Adversarial checks: shrinking candidate box to zero, corrupting sensitivity RHS, unsupported perturbation.
assert any(a[i]>0 for i in range(N))
bad=[(C[i][34]+sum(A[i][j]*x[j] for j in range(N))-x[i]).abs() for i in range(N)]
assert any(v[i]-bad[i]-sum(B[i][j]*v[j] for j in range(N))<0 for i in range(N))
assert Q('.34')**2>slope*slope/(1+slope*slope)
# Counterexample to inferring a nonzero slope merely from J invertible / q1 parameterization:
# (q1,p1)=(t,0) is tangent to its reflected image although derivative of q1 is one.
result={'status':'PASS','nonlinear_radius_max':str(max(h)),'nonlinear_radii':list(map(str,h)),'nonlinear_margin':str(min(margin)),'theta':str(theta),'linear_margin':str(min(lm)),'linear_u_derivative':Z[0].pair(),'terminal_slope':m.pair(),'q2dot':f[1].pair(),'sin_angle_lower':str(sine),'relative_both_tangent_perturbation':str(eps),'arith':'Fraction exact; exact Maclaurin with Lagrange + Lipschitz rounded outward; no CP69F or NumPy','adversarial_wrong_rhs_rejected':True}
(P/'CP69Q_FRACTION_FINAL_RESULT.json').write_text(json.dumps(result,indent=2))
print('PASS Fraction closure',float(theta), 'maxr',float(max(h)),'nonlin margin',float(min(margin)), 'linear margin',float(min(lm)),'slope',float(m.a),float(m.b),'sine>',float(sine))
