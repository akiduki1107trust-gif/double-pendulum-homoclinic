"""New fixed grid and normalized two-variable jet arithmetic. No legacy imports."""
if not __debug__:raise RuntimeError("no -O")
from fractions import Fraction as Q
from math import factorial
from functools import lru_cache
M=10**55
class R:
 __slots__=('a','b')
 def __init__(self,a,b):
  assert type(a)==type(b)==int and a<=b
  self.a,self.b=a,b
 @classmethod
 def q(cls,x):
  x=Q(x);n=x.numerator*M;d=x.denominator
  return cls(n//d,-((-n)//d))
 def __add__(self,o):
  o=C(o);return R(self.a+o.a,self.b+o.b)
 __radd__=__add__
 def __neg__(self):return R(-self.b,-self.a)
 def __sub__(self,o):return self+-C(o)
 def __rsub__(self,o):return C(o)+-self
 def __mul__(self,o):
  o=C(o);v=[self.a*o.a,self.a*o.b,self.b*o.a,self.b*o.b];return R(min(v)//M,-((-max(v))//M))
 __rmul__=__mul__
 def inv(self):
  assert self.b<0 or self.a>0,'division by zero interval';return R(M*M//self.b,-((-M*M)//self.a))
 def __truediv__(self,o):return self*C(o).inv()
 def contains(self,o):return self.a<=o.a<=o.b<=self.b
 def interior(self,o):return self.a<o.a<=o.b<self.b
 def intersect(self,o):return R(max(self.a,o.a),min(self.b,o.b))
 def mag(self):return max(abs(self.a),abs(self.b))
 def __repr__(self):return f'[{self.a}/{M},{self.b}/{M}]'
def C(x):return x if isinstance(x,R) else R.q(x)
ZERO=C(0);ONE=C(1);UNIT=R(-M,M)
@lru_cache(maxsize=30000)
def pointsc(n):
 # Evaluate directly at grid point n/M, no argument reduction.
 x=R(n,n);x2=-x*x;out=[]
 for parity in (1,0):
  term=x if parity else ONE;s=term
  for j in range(1,51):
   term=term*x2/((2*j+parity)*(2*j+parity-1));s=s+term
  d=101+parity;err=C(abs(Q(n,M))**d/factorial(d)).b
  out.append(R(s.a-err,s.b+err).intersect(UNIT))
 return tuple(out)
@lru_cache(maxsize=30000)
def sc(l,r):
 m=(l+r)//2;w=max(m-l,r-m);p=pointsc(m)
 box=[(p[i]+R(-w,w)*R(0,min(M,p[1-i].mag()+w))).intersect(UNIT) for i in (0,1)]
 ends=pointsc(l),pointsc(r);out=[]
 for i in (0,1):
  a,b=ends[0][i],ends[1][i];lo=min(a.a,b.a);hi=max(a.b,b.b);derivative=box[1-i]
  # For cos the derivative is -sin; sign definiteness suffices.
  # If f>=0, f''=-f<=0: min at endpoint. If f<=0: max at endpoint.
  if not (derivative.a>=0 or derivative.b<=0):
   if box[i].a<0:lo=-M
   if box[i].b>0:hi=M
  out.append(box[i].intersect(R(lo,hi)))
 return tuple(out)
def sharp(a,kind):return sc(a.a,a.b)[0 if kind=='sin' else 1]
# Normalize second diagonal derivatives by 2. All products use generated monomial convolution.
exps=[(0,0),(1,0),(0,1),(2,0),(1,1),(0,2)]
conv=[[(i,j) for i,a in enumerate(exps) for j,b in enumerate(exps) if (a[0]+b[0],a[1]+b[1])==k] for k in exps]
class D2:
 __slots__=('c',)
 def __init__(self,x):
  if isinstance(x,D2):self.c=x.c
  elif isinstance(x,(list,tuple)):
   assert len(x)==6;self.c=tuple(C(v)/2 if k in (3,5) else C(v) for k,v in enumerate(x))
  else:self.c=(C(x),ZERO,ZERO,ZERO,ZERO,ZERO)
 @classmethod
 def coeff(cls,x):
  v=cls(0);v.c=tuple(x);return v
 @property
 def v(self):return tuple(2*a if k in (3,5) else a for k,a in enumerate(self.c))
 def __add__(self,o):return D2.coeff([a+b for a,b in zip(self.c,D2(o).c)])
 __radd__=__add__
 def __neg__(self):return D2.coeff([-x for x in self.c])
 def __sub__(self,o):return self+-D2(o)
 def __rsub__(self,o):return D2(o)+-self
 def __mul__(self,o):
  a=self.c;b=D2(o).c;return D2.coeff([sum((a[i]*b[j] for i,j in pairs),ZERO) for pairs in conv])
 __rmul__=__mul__
 def inv(self):
  a=self.c;q=[a[0].inv()]
  # Nilpotent expansion avoids dependency inflation of recursively expanded inverse.
  d=D2.coeff([ZERO,*a[1:]]);inv0=D2(q[0]);return inv0-inv0*inv0*d+inv0*inv0*inv0*d*d
 def __truediv__(self,o):return self*D2(o).inv()
 def __rtruediv__(self,o):return D2(o)*self.inv()
 def sincos(self):
  s,c=sc(self.c[0].a,self.c[0].b);d=D2.coeff([ZERO,*self.c[1:]]);d2=d*d
  return D2(s)+D2(c)*d-D2(s)*d2/2,D2(c)-D2(s)*d-D2(c)*d2/2
# Convenience interface for event computation. Angle lift only, not trig evaluation.
R.center=lambda self:Q(self.a+self.b,2*M)
R.halfwidth=lambda self:Q(self.b-self.a,2*M)
R.load=classmethod(lambda cls,p:cls(int(p[0])*10**10,int(p[1])*10**10))
R.__rtruediv__=lambda self,o:C(o)*self.inv()
@lru_cache(maxsize=1)
def pi_bound():
 def atan(k):
  lo=sum(((-1)**j*Q(1,(2*j+1)*k**(2*j+1)) for j in range(100)),Q(0))
  return lo,lo+Q(1,201*k**201)
 a,b=atan(5);c,d=atan(239)
 lo,hi=16*a-4*d,16*b-4*c
 assert Q(31,10)<lo<hi<Q(22,7)
 return R(C(lo).a,C(hi).b)
