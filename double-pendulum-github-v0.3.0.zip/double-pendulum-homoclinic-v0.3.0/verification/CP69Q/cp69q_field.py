"""Explicit physical Jacobian using scalar interval arithmetic; no automatic differentiation."""
from cp69q_new_kernel import C, R, ZERO, ONE, M, sharp

def field_with_jac(z):
 a,b,p,q=z; co=sharp(a-b,'cos');si=sharp(a-b,'sin');de=2-co*co
 u=(p-co*q)/de;v=(2*q-co*p)/de;w=si*u*v;s1=sharp(a,'sin');s2=sharp(b,'sin');c1=sharp(a,'cos');c2=sharp(b,'cos')
 A=[[] for _ in range(4)]
 for k in range(4):
  ck=[-si,si,ZERO,ZERO][k];sk=[co,-co,ZERO,ZERO][k]
  du=(C(int(k==2))-co*int(k==3)-q*ck+2*co*u*ck)/de
  dv=(2*int(k==3)-co*int(k==2)-p*ck+2*co*v*ck)/de
  dw=sk*u*v+si*du*v+si*u*dv
  for i,x in enumerate([du,dv,-dw-2*c1*int(k==0),dw-c2*int(k==1)]):A[i].append(x)
 return [u,v,-w-2*s1,w-s2],A
