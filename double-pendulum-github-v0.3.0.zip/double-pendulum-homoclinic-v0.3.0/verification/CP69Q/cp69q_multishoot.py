#!/usr/bin/env python3
"""Explicit trust-gate for CP69M uniform 35D state/time charts and sensitivity.
CP69O chart logic retained; replace arithmetic and use explicit physical Jacobian.
"""
from fractions import Fraction as Q
from pathlib import Path
import sys,json,zipfile,hashlib
if not __debug__:raise RuntimeError('no -O')
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'CP69K/G/CP69G'))
from cp69q_new_kernel import R,C,M,ZERO,ONE,sharp,pi_bound
from cp69q_field import field_with_jac
def trig_interval(a,b,kind):return sharp(R(a,b),kind)
read=lambda p:json.loads(p.read_text());qb=lambda t:[Q(t.a,M),Q(t.b,M)];mag=lambda t:max(map(abs,qb(t)))
box=lambda a,b:R(C(a).a,C(b).b)
def sm(v):return sum(v,ZERO)
def rad(c,r):return C(c)+box(-r,r)
def subint(a,b):return b.contains(a)
def energy(z):
 a,b,p,q=z;co=trig_interval((a-b).a,(a-b).b,'cos');de=2-co*co
 return (p*p-2*co*p*q+2*q*q)/(2*de)-2*trig_interval(a.a,a.b,'cos')-trig_interval(b.a,b.b,'cos')
def grad(z):
 f,_=field_with_jac(z);return [-f[2],-f[3],f[0],f[1]]
D=P/'HOMOCLINIC_CP69D_2026-11-18';A=P/'HOMOCLINIC_CP69C_2026-11-18/fresh_35d_rederived_E01/inputs'
anchors=[read(A/'cp38_node0_proxy_anchor.json')]+read(A/'cp34_node_anchors.json')
rawpath=P/'CP69M/CP69M_35D_RAW_RATIONAL24D.json';raw=read(rawpath);J=[[R.load(t) for t in row] for row in raw['J']];E0=Q('1.725e-13');E1=Q('1.542e-8')
graph=read(P/'CP69Q_GRAPH_RESULT.json');lift=read(P/'CP69Q_LIFT_RESULT.json')
assert E0>=Q(lift['Mv'])*Q(graph['graph_height'])
assert E1>=Q(lift['Mv'])*Q(graph['graph_slope'])+Q(lift['Muv'])*Q(graph['graph_height'])
# Source q1 energy-lift bound: use full source strip explicit gradient and implicit derivative.
# Existing E0,E1 independently computed CP69D; their precise equality checked above.
h=Q('.00990902423360074');T=Q('14.7446280595979');delta=T/12-124*h;r=Q('1e-7');r0=Q('2.1e-7');d=Q('1e-15');wide=Q(1,2200);dt=r/12+abs(delta);fudge=100*dt*20/(1-100*dt)
with zipfile.ZipFile(P/'CP69M/UPSTREAM_CP69L_2026-11-19.zip') as z:
 n=next(n for n in z.namelist() if n.endswith('/CP69L_RATIONAL8D_1488STEP_WITNESS.json'));C0= json.loads(z.read(n))
assert int(C0['scale'])==10**45
# verify all exact time fields and all initial inputs, final state time tubes.
records=[];charts=[];Xs=[];Vs=[];fields=[];bounds=[];centers=[];physical_margin=[];box_margin=[];time_margin=[];C0count=0;C1count=0
p=Q('.8242999233');q=Q('.5661533683');h2=Q(anchors[0]['constructing_h2']);u0=Q(anchors[0]['constructing_u']);b0=Q('3.3447126987001807')
state=lambda u:(C(b0)+p*(u+h2*u*u),q*(u-h2*u*u))
for i,nd in enumerate(anchors):
 c=list(map(Q,nd['center']));centers.append(c);e=nd['e'];keep=[k for k in range(4) if k!=e]
 rec=read(P/'CP69M/CP69M_24D'/f'cp69m_24d_{i:02}_124.json')['records']; c0=[t for t in C0['records'] if t['node']==i];assert len(rec)==len(c0)==124
 for k,(a,b) in enumerate(zip(rec,c0)):
  assert a['node']==b['node']==i and a['step']==b['step']==k and Q(a['h'])==Q(b['h'])==h;C0count+=1;C1count+=1
  if k:assert a['input_x']==rec[k-1]['output_x'] and a['input_V']==rec[k-1]['output_V'] and b['input8']==c0[k-1]['output8']
 initial=[R.load(t) for t in rec[0]['input_x'][:4]];initialC0=[R.load(t) for t in c0[0]['input8'][:4]]
 assert all(rec[0]['input_V'][k][j]==[str(10**45*int(j==k))]*2 for k in range(4) for j in range(4))
 xcenter=[C(t) for t in c];xcenter[e]=rad(c[e],d)
 if i==0:
  xcenter[1],xcenter[3]=state(C(u0));xcenter[2]=ZERO
 L=list(xcenter);Rr=list(xcenter);L[e]=C(c[e]-d);Rr[e]=C(c[e]+d)
 Gwide=grad([rad(v,wide) for v in c]);ge=Gwide[e];assert ge.a>0 or ge.b<0
 m=min(map(abs,qb(ge)));assert m>0
 if ge.a>0:assert (energy(L)+Q('.9')).b<0<(energy(Rr)+Q('.9')).a
 else:assert (energy(Rr)+Q('.9')).b<0<(energy(L)+Q('.9')).a
 # root center included in C0 and in uniform C1 initial boxes.
 assert all(a.contains(b) for a,b in zip(initialC0,xcenter))
 assert all(a.contains(b) for a,b in zip(initial,xcenter))
 if i>0:
  dr=d+sum(mag(Gwide[k]) for k in keep)*r/m
  physical=[rad(v,dr if k==e else r) for k,v in enumerate(c)]
 else:
  U=rad(u0,r);Q2,P2=state(U);Q2c,P2c=state(C(u0));Dq=mag(Q2-Q2c);Dp=mag(P2-P2c)
  dr=d+(mag(Gwide[1])*Dq+mag(Gwide[3])*Dp)/m
  physical=[rad(c[0],dr+E0),Q2+box(-E0,E0),ZERO,P2+box(-E0,E0)]
 assert dr<wide
 assert all(a.contains(b) for a,b in zip(initial,physical))
 # both xcenter and source in same uniform box; every difference <=r0 (not the 2*r0 full width).
 margin=min(r0-mag(a-b) for a,b in zip(physical,xcenter));assert margin>0;physical_margin.append(margin)
 if i>0:
  tight=[rad(v,r0) for v in c];assert all(a.contains(b) for a,b in zip(tight,physical));g=grad(tight);assert g[e].a>0 or g[e].b<0
  charts.append([[ONE if k==j else (-g[j]/g[e] if k==e else ZERO) for j in keep] for k in range(4)])
 W=[[R.load(v) for v in row] for row in rec[-1]['output_V']];Wnorm=max(sum(map(mag,row)) for row in W);assert Wnorm<20
 Wshift=[[v+box(-fudge,fudge) for v in row] for row in W]
 if i==0: assert max(sum(map(mag,row)) for row in Wshift)<Q('8.486'); assert Wnorm/(1-100*dt)<Q('8.486')
 ce=[R.load(t) for t in c0[-1]['output8'][:4]]
 # true theta base: mean value along segment from exact center to true input, both in same C1 box.
 spread=[ce[k]+sm(Wshift[k][j]*box(-r0,r0) for j in range(4)) for k in range(4)]
 B=[s+box(Q('-1e-5'),Q('1e-5')) for s in spread];f,Fd=field_with_jac(B)
 assert max(map(mag,f))<100 and max(sum(map(mag,row)) for row in Fd)<100
 tm=Q('1e-5')-dt*max(map(mag,f));assert tm>0;time_margin.append(tm)
 if i<11:
  cn=list(map(Q,anchors[i+1]['center']));bm=min(wide-mag(x-C(v)) for x,v in zip(B,cn));assert bm>0;box_margin.append(bm)
 Xs.append(ce);Vs.append(Wshift);fields.append(f);bounds.append(B)
 records.append({'node':i,'source_box_difference_margin':str(margin),'time_exit_margin':str(tm),'Wnorm':str(Wnorm),'center_C0_inclusion':True,'source_C1_inclusion':True,'next_wide_chart_margin':str(box_margin[-1]) if i<11 else None})
# Reconstruct actual J using same order as CP69M; compare containment, not mere intersection.
U=rad(u0,r);q2,p2=state(U);dq2=p*(ONE+2*h2*U);dp2=q*(ONE-2*h2*U);q01=rad(centers[0][0],Q('1.5e-7'))
# certify proxy root stays in this bracket (uniform signs).
assert (energy([C(centers[0][0]-Q('1.5e-7')),q2,ZERO,p2])+Q('.9')).b<0
assert (energy([C(centers[0][0]+Q('1.5e-7')),q2,ZERO,p2])+Q('.9')).a>0
G=grad([q01,q2,ZERO,p2]);assert G[0].a>0
v0=[-(G[1]*dq2+G[3]*dp2)/G[0],dq2,ZERO,dp2]
J2=[[ZERO for i in range(35)] for j in range(35)]
for i in range(12):
 keep=[0,1] if i==11 else [k for k in range(4) if k!=anchors[i+1]['e']]
 for t,k in enumerate(keep):
  row=3*i+t;J2[row][1]=fields[i][k]/12
  if i==0:J2[row][0]=sm(Vs[0][k][m]*v0[m] for m in range(4))
  else:
   for m in range(3):J2[row][2+3*(i-1)+m]=sm(Vs[i][k][l]*charts[i-1][l][m] for l in range(4))
  if i<11:J2[row][2+3*i+t]=-ONE
# Multiplication order / interval dependency can change a few grid ULPs. Report actual containment and hull if needed.
notin=[(i,j) for i in range(35) for j in range(35) if not J[i][j].contains(J2[i][j])]
# A new enclosure stands on its own. No old matrix containment required.
# time-shift residual computed from center and field tube. Compare sound inclusion directly with frozen residual.
R0=[ZERO]*35
for i in range(12):
 keep=[0,1] if i==11 else [k for k in range(4) if k!=anchors[i+1]['e']]
 for t,k in enumerate(keep):
  R0[3*i+t]=Xs[i][k]+delta*fields[i][k]-(C(centers[i+1][k]) if i<11 else ZERO if k==0 else 2*pi_bound())
rr=[R.load(t) for t in raw['residual']]; residual_contained=sum(a.contains(b) for a,b in zip(rr,R0))
# check exact raw reconstruction using exact operation order from frozen producer if needed; do not assume near equality sound.
# use actual independently rebuilt hull with all exact source corrections in first 3 u entries for sensitivity.
# Export newly rebuilt exact enclosures; old C is a fixed preconditioner only.
def grid45(t):return [str(t.a//10**10),str(-((-t.b)//10**10))]
Jverified=[[grid45(t) for t in row] for row in J2]
(P/'CP69Q_35D_HULL.json').write_text(json.dumps(Jverified,separators=(',',':')))
new={'dimension':35,'scale':10**45,'C':raw['C'],'J':Jverified,'residual':[grid45(t) for t in R0]}
(P/'CP69Q_NEW_PHYSICAL35D.json').write_text(json.dumps(new,separators=(',',':')))
result={'raw_sha256':hashlib.sha256((P/'CP69Q_NEW_PHYSICAL35D.json').read_bytes()).hexdigest(),'nodes':records,'timing_checks':C0count+C1count,'min_source_difference_margin':str(min(physical_margin)),'min_end_chart_margin':str(min(box_margin)),'min_time_exit_margin':str(min(time_margin)),'time_span_steps':str(124*h),'var0_time_corrected_bound':str(max(sum(map(mag,row)) for row in Vs[0])),'original_J_containment_count':1225-len(notin),'hull_expanded_for_entries':notin,'old_residual_contains_count':residual_contained,'E0':str(E0),'E1':str(E1),'E0_E1_graph_compatible':True,'status':'PASS'}
(P/'CP69Q_MULTISHOOT_RESULT.json').write_text(json.dumps(result,indent=2));print('PASS multishoot gate', {k:float(Q(result[k])) for k in ('min_source_difference_margin','min_end_chart_margin','min_time_exit_margin','var0_time_corrected_bound')},'J contain',1225-len(notin),'old residual contained',residual_contained)
