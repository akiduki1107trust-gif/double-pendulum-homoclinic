"""Independent structural and rational comparison audit of the public R evidence. No old verifier imports."""
import sys, json, zipfile, io, hashlib, gzip
from fractions import Fraction as Q
from pathlib import Path
if not __debug__: raise RuntimeError('assertions required')
sha=lambda b:hashlib.sha256(b).hexdigest()
def z(b):return zipfile.ZipFile(io.BytesIO(b))
def one(a,s):
 ns=[n for n in a.namelist() if n.endswith(s)];assert len(ns)==1,(s,ns);return a.read(ns[0])
def j(a,s):return json.loads(one(a,s))
raw=Path(sys.argv[1]).read_bytes();assert sha(raw)=='81fea80b10873aedc354679ce7307f04d9df76d57374e06c9fe83a2cf61b624a'
r=z(raw);q=z(one(r,'HOMOCLINIC_CP69Q_2026-11-21_研究資料.zip'));p=z(one(q,'HOMOCLINIC_CP69P_2026-11-20_研究資料.zip'));o=z(one(p,'HOMOCLINIC_CP69O_2026-11-20_研究資料.zip'));h=z(one(p,'HOMOCLINIC_CP69H_2026-11-19_研究資料.zip'));g=z(one(h,'UPSTREAM_HOMOCLINIC_CP69G_2026-11-19_研究資料.zip'));n=z(one(o,'UPSTREAM_CP69N_2026-11-20.zip'));m=z(one(n,'UPSTREAM_CP69M_2026-11-19.zip'));l=z(one(m,'UPSTREAM_CP69L_2026-11-19.zip'));d=z(one(o,'UPSTREAM_CP69D_2026-11-18.zip'))
# The D archive includes the exact source anchors; select names by unique suffix.
a=j(d,'cp38_node0_proxy_anchor.json');nodes=j(d,'cp34_node_anchors.json');assert len(nodes)==11 and a['e']==0
assert Q(a['constructing_h2'])==Q('-.0026488571962644')
u=Q(a['constructing_u']);t=Q('14.7446280595979');r0=Q('1e-7');ell=Q('1.634e-6');eps=Q('3.5e-13');radius=Q('4e-5');wide=Q(1,2200)
assert t-r0>0 and u-r0>ell and u+r0<radius
P=Q('.8242999233');R=Q('.5661533683');b=Q('3.3447126987001807');h2=Q(a['constructing_h2'])
assert Q(a['q2'])==b+P*(u+h2*u*u) and Q(a['p2'])==R*(u-h2*u*u)
assert Q(a['coordinate_exact_rationals'][1])==Q(a['q2']) and Q(a['coordinate_exact_rationals'][3])==Q(a['p2'])
rr=j(r,'CP69R_RESULT.json');C0=one(l,'CP69L_RATIONAL8D_1488STEP_WITNESS.json');assert sha(C0)==rr['raw_C0_sha256'];c0=json.loads(C0)['records'];assert len(c0)==1488
S=10**45
# Directly tie physical C1 input boxes to broad energy-root charts used for the IFT.
count=0
for i,nd in enumerate([a]+nodes):
 raw1=one(m,f'CP69M_24D/cp69m_24d_{i:02d}_124.json');assert sha(raw1)==rr['raw_C1_sha256'][i]
 rec=json.loads(raw1)['records'];assert len(rec)==124
 center=list(map(Q,nd['center']));assert len(center)==4
 for (lo,hi),c in zip(rec[0]['input_x'][:4],center):
  assert c-wide<Q(int(lo),S)<=Q(int(hi),S)<c+wide;count+=1
 if i==0:
  assert Q('.347')<Q(int(rec[0]['input_x'][0][0]),S) and Q(int(rec[0]['input_x'][0][1]),S)<Q('.351')
 # actual flow times are fixed, not inferred from step count alone.
 for k,(a0,a1) in enumerate(zip([w for w in c0 if w['node']==i],rec)):
  assert a0['step']==a1['step']==k and Q(a0['h'])==Q(a1['h'])==Q('.00990902423360074')
# Local anchor data match the Q geometry and have the same raw first jet on the two branches.
parts=sorted(s for s in g.namelist() if 'c2_traces/' in s and s.endswith('.gz'));assert len(parts)==14
last=None;total=0
for f in parts:
 w=json.loads(gzip.decompress(g.read(f)));assert w['lo']==total
 if last is not None:assert w['first']==last
 else:
  def dy(v):sg,m,e,b=v;return (-1 if sg else 1)*Q(m)*Q(2)**e
  for name in ('X','C'):
   lo,hi=map(dy,w['first'][name][0][0]);assert Q('.347')<lo<=hi<Q('.351')
 total+=len(w['records']);assert w['end_step']==total;last=w['last']
assert total==267
# Resolve two distinct final-matrix filenames; they must identify the same interval matrix.
raw35=j(q,'CP69Q_NEW_PHYSICAL35D.json');hull=j(q,'CP69Q_35D_HULL.json');assert raw35['J']==hull and len(hull)==35 and all(len(x)==35 for x in hull)
mu=j(q,'CP69Q_MULTISHOOT_RESULT.json');assert sha(one(q,'CP69Q_NEW_PHYSICAL35D.json'))==mu['raw_sha256'];assert mu['timing_checks']==2976
G=j(q,'CP69Q_GRAPH_RESULT.json');L=j(q,'CP69Q_LIFT_RESULT.json');F=j(q,'CP69Q_FRACTION_FINAL_RESULT.json');
assert Q(G['graph_height'])<eps and Q(G['graph_slope'])<Q('2e-8') and Q(G['graph_transform_lip'])<1 and Q(G['inverse_base_lip'])<1
assert Q(G['coverage_left'])>radius and Q(G['coverage_right'])<-radius
assert Q(G['fixed_reflection_u_bound'])<ell and Q(G['fixed_reflection_v_bound'])<eps and Q(G['u_source_separation'])>Q('3.1243e-5')
assert Q(L['Mv'])*Q(G['graph_height'])<Q(mu['E0']) and Q(L['Mv'])*Q(G['graph_slope'])+Q(L['Muv'])*Q(G['graph_height'])<Q(mu['E1'])
assert Q(mu['var0_time_corrected_bound'])<Q('8.486')
assert Q(F['nonlinear_margin'])>0 and Q(F['linear_margin'])>0
assert all(0<Q(x)<r0 for x in F['nonlinear_radii'])
ml,mh=map(Q,F['terminal_slope']);assert Q('.3527')<ml<=mh<Q('.6854')
# Strictly strengthen the conditional hyperbolicity bound without approximating any eigenvalue.
a=Q('24.6405');c=Q(G['Y_v_bound']);lam=Q('24.5');trace_lower=a-c;assert trace_lower>Q("24.5999") and trace_lower>lam+1/lam
# det DF=1: |lambda_u|+1/|lambda_u|=|tr DF|, monotone above 1.
# F^2 is the full-period germ, hence its multipliers obey the squared bounds.
print(json.dumps({'status':'PASS','source_broad_chart_coordinates':count,'long_time_fields':2976,'local_C2_steps_bound':total,'J_raw_equals_hull_components':1225,'source_chart_constants_equal':True,'graph_and_lift_budget_consistent':True,'shooting_radius_max':str(max(map(Q,F['nonlinear_radii']))),'terminal_slope_display':[float(ml),float(mh)],'determinant_lower_strict':'0.7054','trace_abs_lower_strict':'24.5999','full_period_unstable_multiplier_abs_lower_strict':str(lam**2),'full_period_stable_multiplier_abs_upper_strict':str(1/lam**2),'scope':'Exact archive/data linkage and rational comparisons; no new ODE integration in this script. Eigenvalue bound conditional on actual area-preserving return map.'},indent=2))
