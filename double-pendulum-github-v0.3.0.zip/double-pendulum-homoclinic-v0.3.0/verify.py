#!/usr/bin/env python3
"""Authenticate/unpack the immutable CP69-T archive and run its original verifier."""
import argparse, hashlib, pathlib, subprocess, sys, tempfile, zipfile
EXPECTED = "47588ab27e1292a84493f575b6acb3d5a988192c165105039767896dc472f76c"
if not __debug__: raise RuntimeError("Do not use Python -O")
p = argparse.ArgumentParser(description=__doc__)
p.add_argument("archive", type=pathlib.Path)
g=p.add_mutually_exclusive_group()
g.add_argument("--full", action="store_true", help="Also rerun both upstream ODE gates")
g.add_argument("--integrity-only", action="store_true", help="Check archive and internal manifest; no proof arithmetic")
a=p.parse_args()
with a.archive.open("rb") as f:
    if hashlib.file_digest(f,"sha256").hexdigest()!=EXPECTED: raise SystemExit("Archive SHA-256 mismatch")
with tempfile.TemporaryDirectory(prefix="cp69t-public-") as td:
    root=pathlib.Path(td)
    with zipfile.ZipFile(a.archive) as z:
        for info in z.infolist():
            name=pathlib.PurePosixPath(info.filename)
            if name.is_absolute() or '..' in name.parts or not name.parts or name.parts[0]!='CP69T': raise SystemExit("Unsafe/unknown archive member")
        if z.testzip() is not None: raise SystemExit("Archive CRC failure")
        z.extractall(root)
    cp=root/"CP69T"
    import json
    manifest=json.loads((cp/"SHA256.json").read_text())
    if len(manifest)!=16: raise SystemExit("Unexpected manifest count")
    for name,digest in manifest.items():
        if pathlib.PurePath(name).name!=name or hashlib.sha256((cp/name).read_bytes()).hexdigest()!=digest: raise SystemExit("Manifest mismatch: "+name)
    print("PASS CP69-T outer digest, CRC and 16 manifest entries", flush=True)
    if not a.integrity_only:
        subprocess.run([sys.executable,str(cp/"CP69T_VERIFY.py")]+(["--full"] if a.full else []),cwd=cp,check=True)
