# Changelog

## v0.3.0 — CP69-T (2026-11-21)
- Direct source-graph tangent enclosure; removes the old E1 derivative-proxy error from the final proof route.
- Reconstructs 35 residuals, 1,225 Jacobian intervals and 70 strict weighted inequalities.
- Normalized determinant > 0.70590; terminal speed > 0.74006.
- Archived `local-full` and `long` successful exit codes recovered by new executions at T.
- Integrated mathematical enclosure semantics and analytic nonintegrability argument; English manuscript and unmodified evidence archive.
- External review, full formalization and priority unverified.

## v0.2.0 — CP69-S
Historical audit retained in the immutable archive and in review copies; no previous released files overwritten.
