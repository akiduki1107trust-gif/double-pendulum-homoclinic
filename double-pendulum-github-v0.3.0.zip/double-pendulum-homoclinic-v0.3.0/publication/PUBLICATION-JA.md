# GitHub・Zenodo 投稿手順 — CP69-T / v0.3.0

2026年11月21日研究版。GitHubとZenodoの既存v0.2.0を変更せず、新しい版として公開するための資料。

## 1. GitHub
1. 既存の二重振り子リポジトリを開く（未作成なら https://github.com/new ）。
2. `double-pendulum-github-v0.3.0.zip` を解凍し、中の `double-pendulum-homoclinic-v0.3.0` フォルダの**内容**をリポジトリの新しいコミットとして追加する。`.zenodo.json` 等の隠しファイルも含める。既存タグ v0.2.0 は移動しない。古い v0.2.0 固有ファイルは削除または履歴として明示する。
3. Releases > Draft a new release。タグ `v0.3.0`、タイトル `CP69-T — Direct true tangent and classical proof closure`。本文は `publication/RELEASE-NOTES.md` を使用。
4. Releaseの添付ファイルに英文PDF、`double-pendulum-CP69T-evidence.zip`、SHA256SUMSを追加する。66.9 MBの原ZIPはブラウザで通常のコミットに追加できる25 MiB上限を超えるため、Releaseのassetsへアップロードする。
5. 著者情報・公開権利・ライセンスを最終確認し、プレリリースとして公開を推奨。

任意のGitコマンド例（既存clone内で実行。実在のURLは利用者が確認）：

```bash
git status
git add -A
git commit -m 'Release CP69-T v0.3.0'
git tag -a v0.3.0 -m 'CP69-T research preprint'
git push
git push origin v0.3.0
```

GitHub公式: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository

## 2. Zenodo
1. 既存の該当プレプリントが公開済みなら `New version` を選択（https://help.zenodo.org/docs/deposit/manage-versions/ ）。未公開なら https://zenodo.org/uploads/new で新規登録。
2. Resource type = Publication / Preprint、Version = 0.3.0。英語題名・著者名・要旨・キーワードを `ZENODO-METADATA.md` からコピーする。
3. 英文PDF、原証明書ZIP、GitHubソースZIP、SHA256SUMSの4ファイルを添付。ライセンスは権利を確認後に選択。既存DOI・ORCIDを推測しない。日付は実際の公開日。
4. プレビューを確認してPublish。DOIが発行されたら実際のDOI URLをGitHubのREADME、CITATION.cffへ反映。既存のDOIやタグ、原ZIPは上書きしない。
5. 自動GitHub連携を利用する場合、その記録はソフトウェアの別記録になる。GitHubの自動生成ソースZIPにはRelease添付ファイルが含まれないため、手動Zenodo記録には原証明書ZIPを必ず含める。

## 3. 原証明書の再現

```bash
python verify.py double-pendulum-CP69T-evidence.zip --integrity-only
python verify.py double-pendulum-CP69T-evidence.zip
python verify.py double-pendulum-CP69T-evidence.zip --full
```

2番目は新しい直接証明と入力連結の再現。3番目は上流ODE全件の再計算を含む。今回の投稿整備では2番目相当の原検証器を再実行して一致確認したが、上流ODE全件は再計算していない（原CP69-Tの両終了コード0を保存）。外部独立査読・全Lean形式化・初出性確認は未実施。

原ZIP SHA-256: `47588ab27e1292a84493f575b6acb3d5a988192c165105039767896dc472f76c`

公開前に、著者本人が公開範囲、ライセンス、英語原稿、原アーカイブの権利とプライバシーを確認すること。今回の版は投稿可能なファイル一式であり、実際のGitHub/Zenodo公開やDOI取得は行っていない。
