# Before public release

- Author name and affiliation carried over from the v0.2.0 metadata; confirm spelling and consent. No ORCID, DOI, repository address or external referee approval was invented.
- Verify that you have redistribution rights for every file in the nested archive. No blanket new license assigned here; consider CC BY 4.0 for your manuscript/data and an explicit software license for your own code only. GitHub/Zenodo availability is not a license grant for third-party content.
- Inspect archives for credentials, private data and sensitive identifiers before publication. Packaging checks are not a complete privacy/copyright audit.
- Check English mathematical statement against the original Japanese proof and exact verifier output. In particular graph identification, matching of chart branches, all finite enclosures, and persistence in nearby energies must be independently reviewed.
- The old v0.2.0 proof status is historical. The new manuscript records internal classical closure, not independent acceptance. Full Lean and exhaustive novelty review remain incomplete.
- Add actual DOI and repository URL in a subsequent citation/metadata update; never rewrite historical archives or tags. Confirm actual publication date.
