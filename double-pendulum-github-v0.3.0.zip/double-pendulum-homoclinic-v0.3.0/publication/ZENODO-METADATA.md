# Zenodo metadata — manual preprint deposit v0.3.0

**Title**  
A Computer-Assisted Proof of a Transverse Homoclinic Orbit in the Equal-Mass, Equal-Length Double Pendulum at Energy -9/10

**Creator**  
Family name: Harada  
Given name: Shigehisa  
Affiliation: Independent Researcher  
ORCID: omit unless verified by author.

**Resource type:** Publication / Preprint  
**Version:** 0.3.0  
**Publication date:** actual day of release (research version prepared 2026-11-21)  
**Language:** English  
**Access:** Public after author approval  
**License:** Suggest CC BY 4.0 for author-owned paper/data only after rights approval; software license must be confirmed separately. Do not license all nested files indiscriminately. Separate records or license per file if rights require it.  
**DOI:** Create a new version of the previous preprint record if present; otherwise create a new record. No DOI has been assigned in this packaging session.

## Description (paste below)

We present a classical computer-assisted proof of a nontrivial transverse homoclinic orbit to a hyperbolic periodic orbit in the planar double pendulum with unit masses, lengths and gravity, at energy H = -9/10. A symmetry-composed return map, Lipschitz graph transform and 35-variable multiple shooting establish existence. CP69-T directly encloses the tangent to the true unstable graph through the energy constraint, without a proxy derivative correction, and reconstructs the 1,225 Jacobian entries. The section slope satisfies 0.35295 < m < 0.68516 and the normalized determinant exceeds 0.70590. The archived internal full ODE replays report exit code zero for both gates: 4,047 steps and 127,296 Picard–Taylor inclusion conditions, plus 175 previous integer checks. The new gate checks 12 initial charts and 70 strict existence/sensitivity inequalities. The proof yields a Smale–Birkhoff horseshoe and a global real-analytic nonintegrability consequence. This is an internally closed classical computer-assisted proof claim, under ordinary trusted exact computation, not a peer-reviewed or fully machine-formalized result. Independent expert review and priority verification remain outstanding. The artifact includes the English manuscript, original Japanese integrated proof, source, exact data and reproduction logs. Research and manuscript developed with AI assistance (ChatGPT).

## Keywords

double pendulum; transverse homoclinic orbit; Smale–Birkhoff horseshoe; Hamiltonian dynamics; validated numerics; interval arithmetic; multiple shooting; nonintegrability

## Upload these files

1. Harada_Double_Pendulum_CP69T_Preprint_v0.3.0.pdf
2. double-pendulum-CP69T-evidence.zip
3. double-pendulum-github-v0.3.0.zip
4. Double_Pendulum_v0.3.0_SHA256SUMS.txt

## Citation

Harada, S. (2026). *A Computer-Assisted Proof of a Transverse Homoclinic Orbit in the Equal-Mass, Equal-Length Double Pendulum at Energy -9/10* (v0.3.0, CP69-T). Preprint. Add actual DOI after registration.

Related identifiers: actual GitHub release URL and prior version identifiers, only when confirmed. Do not mix the DOI of an automatic GitHub software archive with this manual preprint DOI.
